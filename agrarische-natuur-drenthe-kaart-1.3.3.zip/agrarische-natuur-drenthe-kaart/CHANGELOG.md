# Changelog

## 1.3.3

- De witte resultaatachtergrond loopt mobiel 20px achter de afgeronde onderrand van de kaart door, zodat beide onderdelen visueel beter aansluiten.
- De ondertitel onder `Perceelscheck` is verwijderd; `Bekijk je kansen per adres` staat nu als vaste placeholder in het zoekveld op alle schermformaten, waardoor het paneel compacter is.
- Het mobiele zoekveld gebruikt de beschikbare breedte efficiënter en schaalt de tekst op de smalste schermen licht mee.
- Lange ingevoerde adressen vervagen op alle schermformaten subtiel onder een eigen volledig dekkend wiskruisje, zodat er geen tekst door de knop zichtbaar blijft.
- Het MapLibre-canvas volgt mobiel exact de kaartcontainer, waardoor bij halve pixelhoogtes geen donkere haarlijn meer onder de kaart ontstaat.
- Tablets tot en met 1024px gebruiken in portretstand dezelfde compacte kaart- en resultaatopbouw als mobiele telefoons; in landschap blijft het zwevende paneel behouden.
- Op tablets in portretstand zijn het zoekveld en de lagenknop samen begrensd op 620px en als één groep boven de kaart gecentreerd.
- Titel en kaart worden vanaf 1024px expliciet rond het midden van de WordPress-contentcontainer geplaatst, zodat themapadding geen horizontale verschuiving meer veroorzaakt.
- De zoomknoppen met plus en min zijn verborgen op compacte weergaven tot en met 1024px en op touch-tablets tot en met 1366px, in zowel portret als landschap.
- Het groene vlak met beschikbare beheerpakketten heeft een subtiele rand van 1px in `#A2D1AB`.
- In tablet-portret gebruiken titel en kaart opnieuw de beschikbare schermbreedte met 20px zijmarge, in plaats van de smallere WordPress-contentkolom.
- In alle compacte weergaven staat het zoekveld weer exact 20px onder de bovenrand van de kaart; een oude desktopmarge werkt hier niet langer door.
- De frontend-CSS is opgeschoond: ongebruikte variabelen en subtitelopmaak zijn verwijderd, overbodige mobiele resets zijn geschrapt en brede input- en buttonselectors zijn beperkt tot de bedoelde onderdelen.
- De positionering van zoekveld en kaartlagenknop gebruikt weer de gecentreerde tabletregel; de margecorrectie is losgekoppeld zodat deze de horizontale uitlijning niet meer kan overschrijven.
- De compacte tabletweergave wordt tot en met 1024px nu op breedte gekozen in plaats van op portretoriëntatie, zodat bijna vierkante en liggende schermen rond 853–1004px niet onverwacht de grote desktop-overlay tonen.
- De kaartlagenknop gebruikt in JavaScript exact dezelfde compacte grens van 1024px als de CSS, zodat de pop-over ook op liggende en bijna vierkante tablets opent.
- De integriteitscontrole van actieve kaartbestanden gebruikt na een volledige SHA-256-controle een cache op basis van bestandsmetadata; activeren blijft altijd een volledige controle uitvoeren en wijzigingen maken de cache ongeldig.
- Geüploade kaartdata kan veilig via het door WordPress ingestelde publieke upload-/CDN-domein worden geladen, terwijl onbekende externe herkomsten geweigerd blijven.
- De technische documentatie beschrijft de actuele responsive grens, integriteitscache en CDN-ondersteuning.
- Het adresveld gebruikt op telefoons en touch-tablets minimaal 16px invoertekst, zodat iOS Safari de volledige pagina en kaart niet meer automatisch vergroot wanneer het veld focus krijgt; de compacte placeholder behoudt zijn kleinere visuele formaat.

## 1.3.2

- Adres- en straatautocomplete via PDOK, beperkt tot Drenthe en beschikbaar vanaf drie tekens.
- Toetsenbordbediening, korte typvertraging en behoud van de gewone zoekroute als suggesties niet beschikbaar zijn.
- Perceel- en beheerpakketblokken gebruiken rondom 20px binnenruimte.
- Zoomknoppen zijn op mobiele schermen verborgen; tablet en desktop blijven ongewijzigd.
- Het perceelblok is verticaal compacter; lange adressen blijven op één regel en worden met een beletselteken afgekort.
- Nieuwe minimalistische mobiele weergave met zoekveld en zoekicoon over de kaart, een toegankelijke kaartlagen-pop-over en resultaten onder de kaart.
- Aangeleverde SVG-iconen voor zoeken, kaartlagen en de perceelchevron; de nieuwe chevron geldt op alle schermformaten.
- De mobiele kaartlagenknop behoudt zijn icoon bij hover, vergroot subtiel en toont bij een geopend menu een sluitkruis.
- Zoekveld en kaartlagenknop staan mobiel 20px van de kaartrand en 20px van elkaar.
- Het mobiele resultatenpaneel gebruikt 20px binnenruimte en 20px afstand tussen adres, beheerpakketten en bronvermelding.

## 1.3.1

- Mobiel (tot en met 640px): kaart met verhouding 4:3, 25% lager dan de eerdere vierkante kaart, boven een even breed paneel met 15px overlap. Het paneel groeit mee met resultaten, zonder intern scrollvak.
- Mobiele zoekveldhoeken van 10px en 15px afstand tot de losse zoekknop; bronvermelding blijft zichtbaar boven het paneel.
- Desktoplayout en kaartdata blijven ongewijzigd.
- Regressietest voor de lagere mobiele kaart met een meegroeiend paneel en vaste overlap.

## 1.3.0

- Responsieve kaartuitsnede op basis van het echte informatiepaneel, zonder ongeldige vaste desktopmarges op mobiel.
- Vorige perceelomlijning, marker en resultaten worden gewist vóór iedere nieuwe selectie.
- Gedeelde selectiecontroller voor adreszoeken en kaartklikken, met consistente fout- en herstelafhandeling.
- Regressietests voor opeenvolgende selecties, kaartbreedtes van 280–1297 pixels, paneelgroei en afzonderlijke kaartinstanties.

- Frontend opgesplitst in modules voor kaartweergave, datasets/overlap, PDOK en resultaten, met een centrale coördinator.
- Geen terugval naar een willekeurig naburig perceel wanneer de gekozen positie nergens binnen valt.
- PDOK-timeout van 15 seconden per aanvraag en een datalaadlimiet van 60 seconden; zoekbediening wordt na een fout weer vrijgegeven.
- Regressietests voor perceelkeuze, timeouts tijdens downloaden en JSON-inlezen, en opnieuw zoeken na fouten.

- Rekenfouten bij overlap worden als onbetrouwbare controle gemeld in plaats van als geen overlap.
- Herhaalde zoekacties worden tijdens een lopende aanvraag geblokkeerd; laagkeuzes blijven tijdens laden behouden.
- Strikte broncodes voor nieuwe uploads en een expliciete formaatmarkering voor complete driedelige versies.
- Geen ongecontroleerde terugval bij een ontbrekende actieve versiereferentie.
- Jaarneutrale gegevensnamen voor nieuwe uploads; eerdere bestandsformaten blijven bruikbaar.
- Tegelgrootte, veilige bronlinks en herstel van OpenStreetMap toegevoegd.
- Lora en Open Sans lokaal opgenomen met OFL-licenties; ongebruikte CSS en inline stijlen opgeruimd.
- Frontendregressietests en geïsoleerde WordPress-integratietests toegevoegd.

- Beheerbare achtergrondkaart met gevalideerd HTTPS-tegeladres, bronvermelding en optionele publieke browser-token.
- Nieuwe kaartversies bestaan uit drie afzonderlijk gevalideerde uploads: Agrarisch zoekgebied, Waterkaart en Klimaatkaart.
- Water en Klimaat blijven intern afzonderlijk en worden aan de voorkant als één categorie geladen en doorzocht.
- Activeren en terugschakelen behandelt alle bestanden als één complete versie.
- Bestaande kaartversies met een gecombineerd bestand voor Water en klimaat blijven ondersteund.

## 1.2.1

- SHA-256-integriteitscontrole toegevoegd voor de daadwerkelijk geladen JavaScript-kaartbestanden.
- Vaste hashes toegevoegd voor de ingebouwde kaartdata van 2026.
- Nieuwe uploads bewaren hashes voor zowel GeoJSON als de gegenereerde JavaScript-varianten.
- Bestaande geüploade kaartversies blijven compatibel via reproduceerbare JS-hashafleiding.

## 1.2.0

- Datasetvalidatie en versieopslag opgesplitst in afzonderlijke klassen.
- Transactionele uploadopslag via tijdelijke map en verificatie vóór registratie.
- Concrete foutmeldingen voor bestandstype, JSON, geometrie, coördinaten en categoriecodes.
- Maximale uploadgrootte verlaagd naar 10 MB per dataset.
- Activering weigert ontbrekende of beschadigde kaartversies.
- Ongebruikte uitlijn-, QGIS- en kadastrale controlecode verwijderd.
- Bounding-boxvoorselectie toegevoegd vóór kostbare Turf-intersecties.
- Beheer-CSS uit PHP gehaald.
- Documentatie en reproduceerbare datatests toegevoegd.

## 1.1.0

- Progressief laden van basiskaart en kaartdatasets.
- Lokale, vastgepinde MapLibre- en Turf-afhankelijkheden.
- Uitgebreide uploadvalidatie, HTTPS-links, auditlog en terugrolbare kaartversies.

## 1.0.0

- Eerste WordPress-plugin met vijf shortcodes, beheerpagina en kaartversies.
