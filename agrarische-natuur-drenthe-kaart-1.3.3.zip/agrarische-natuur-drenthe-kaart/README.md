# Agrarische Natuur Drenthe – Perceelscheck

WordPress-plugin voor een interactieve kaart van het Natuurbeheerplan Drenthe en een indicatieve perceelscheck.

## Architectuur

De plugin verdeelt de verantwoordelijkheden als volgt:

1. `AND_Kaart_Plugin` registreert WordPress-hooks, beheerpagina en shortcodes.
2. `AND_Kaart_Dataset_Validator` valideert en normaliseert nieuwe GeoJSON-datasets.
3. `AND_Kaart_Version_Repository` schrijft complete kaartversies transactioneel weg en activeert bestaande versies.
4. `assets/perceelscheck.js` initialiseert iedere kaart en coördineert laden, zoeken en klikken.
5. `AND_Kaart_Tile_Settings` controleert instellingen voor de achtergrondkaart en verwerkt de bronvermelding.

De frontend gebruikt zeven afzonderlijke modules met expliciet doorgegeven afhankelijkheden en eigen toestand per kaart:

- `assets/datasets.js`: categorieën, brondata, ruimtelijke voorselectie en overlapcontrole.
- `assets/map-view.js`: lagen, provinciecontour, kaartpositie en geselecteerd perceel/marker.
- `assets/pdok.js`: adreszoeken, omgekeerd adreszoeken en perceelopvragen.
- `assets/results-view.js`: weergave van beschikbare beheerpakketten.
- `assets/selection-controller.js`: gedeelde afhandeling van adreszoeken en kaartklikken, inclusief opruimen, foutmeldingen en vrijgeven van de bediening.
- `assets/address-autocomplete.js`: vertraagde PDOK-adressuggesties, inclusief toetsenbordbediening en afgeschermde toestand per kaart.
- `assets/mobile-controls.js`: compacte zoekpresentatie en toegankelijke kaartlagen-pop-over.

WordPress laadt deze modules vóór de coördinator via script-afhankelijkheden. Er is geen extra bundelstap nodig. De bestaande `geometry.js` blijft de gedeelde geometriehelper.

Een nieuwe selectie wist onmiddellijk de vorige perceelomlijning, marker en resultaten. Bij een technische fout worden ook gedeeltelijke resultaten opgeruimd. Als wel een nieuwe locatie maar geen perceel wordt gevonden, blijft uitsluitend de marker van die nieuwe locatie staan met een melding zonder overlapuitslag.

Bij het passend weergeven van provincie of adresperceel wordt de werkelijke kaart- en paneelafmeting gemeten. De kaart gebruikt de grootste vrije ruimte naast of boven/onder het paneel. Die meting gebeurt bij adresresultaten nadat de resultaatinhoud zichtbaar is; padding blijft altijd kleiner dan het kaartvlak. Kaartklikken behouden het bestaande zoomgedrag (minimaal 12,5, een verder ingezoomde kaart blijft ingezoomd).

Vanaf versie 1.3.2 staat in de compacte layout de zoekbalk over de 4:3-kaart. Deze opbouw geldt voor alle schermen tot en met 1024px, ongeacht de oriëntatie. Kaartlagen openen vanuit een ronde knop in een tijdelijke pop-over. Alleen na een selectie verschijnt een compact resultatenpaneel onder de kaart. Vanaf 1025px wordt het zwevende paneel gebruikt.

Een perceel wordt alleen teruggegeven als het de gekozen positie bevat; een naburig perceel wordt niet als vervanging gebruikt. PDOK-aanvragen hebben per aanvraag maximaal 15 seconden, inclusief het inlezen van de respons. Bij een timeout wordt de zoekbediening weer vrijgegeven. Het zoeken naar een perceel kan maximaal drie opeenvolgende zoekgebieden proberen; een technische fout stopt de controle. Een mislukte optionele adresnaam bij een kaartklik verhindert een geslaagde perceelcontrole niet. Kaartdatabestanden hebben een laadtijdlimiet van 60 seconden; bij mislukking wordt gevraagd de pagina te vernieuwen.

Vanaf drie ingevoerde tekens vraagt de zoekbalk na een korte vertraging maximaal acht adres- en straatsuggesties binnen Drenthe op bij PDOK. De lijst ondersteunt muis, aanraking en de toetsen pijl omhoog/omlaag, Enter en Escape. Als suggesties tijdelijk niet beschikbaar zijn, blijft de gewone zoekopdracht via Enter of de knop werken.

De basiskaart en provinciecontour verschijnen eerst. Agrarisch, Water en Klimaat downloaden parallel. Nieuwe versies gebruiken afzonderlijke Water- en Klimaatkaartbronnen, aangestuurd door één schakelaar. Overlapresultaten verschijnen onder één categorie. De perceelscheck wordt vrijgegeven als alle bestanden van de actieve versie gereed zijn.

Bij activering controleert WordPress de volledige SHA-256-hash van ieder kaartbestand. Tijdens gewone paginaweergaven wordt die uitslag kort hergebruikt zolang bestandsgrootte en wijzigingstijden gelijk blijven; een gewijzigd bestand maakt de cache automatisch ongeldig. Daarmee blijft de integriteitscontrole behouden zonder alle grote databestanden bij iedere shortcode opnieuw volledig te lezen.

## Data

| Bestand | Functie |
|---|---|
| `data/agrarisch_2026.js` | Browserdata voor A11, A12 en A15 |
| `data/agrarisch_2026.geojson` | Onderhoudsbestand van dezelfde data |
| `data/water_klimaat_2026.js` | Browserdata voor W01/K01 |
| `data/water_klimaat_2026.geojson` | Onderhoudsbestand van dezelfde data |
| `data/provincie_drenthe.js` | Contour en masker van Drenthe |

De `.geojson`-bestanden worden niet door bezoekers gedownload. Bij een upload bewaart WordPress zowel het onderhoudsbestand als de gegenereerde `.js`-variant; alleen de `.js`-variant wordt aan de kaart geleverd.

Wanneer WordPress-uploads via een afzonderlijk publiek CDN- of mediadomein worden geleverd, neemt de shortcode dat domein gericht op in de toegestane databronnen. Andere, niet door WordPress opgegeven herkomsten blijven geweigerd.

## Officiële bronnen

- Provincie Drenthe: *Natuurbeheerplan 2026 – Agrarisch zoekgebied*.
- Provincie Drenthe: *Natuurbeheerplan 2026 – Waterkaart*.
- Provincie Drenthe: *Natuurbeheerplan 2026 – Klimaatkaart*.
- PDOK Locatieserver voor adreszoeken en reverse geocoding.
- PDOK/Kadaster BRK Kadastrale Kaart voor perceelgeometrie.
- OpenStreetMap voor de achtergrondkaart.

## Jaarlijkse kaartupdate

1. Bereid buiten WordPress drie geoptimaliseerde WGS84-GeoJSON-bestanden voor.
2. Gebruik voor Agrarisch uitsluitend `agrarischNatuurType` met A11, A12 of A15.
3. Gebruik voor de Waterkaart uitsluitend `waterClimateType` met W01 en voor de Klimaatkaart uitsluitend K01.
4. Open in WordPress **Kaart → Nieuwe kaartversie uploaden**.
5. Upload alle drie de bestanden onder één herkenbare versie-/jaargangnaam.
6. Controleer de nieuwe versie; een upload wordt nooit automatisch actief.
7. Activeer de versie handmatig. Bij fouten kan iedere oudere complete versie opnieuw worden geactiveerd.

Uploads zijn maximaal 10 MB per bestand. Alleen gesloten Polygon/MultiPolygon-geometrie binnen het WGS84-bereik rond Drenthe wordt geaccepteerd. Onnodige attributen worden verwijderd en coördinaten worden afgerond op zes decimalen.

## Achtergrondkaart

Onder **Kaart → Achtergrondkaart** kan een beheerder het HTTPS-tegeladres, de zichtbare bronvermelding en eventueel een publieke browser-token instellen. Het tegeladres moet `{z}`, `{x}` en `{y}` bevatten. Een token wordt alleen ingevuld wanneer het adres de tijdelijke aanduiding `{token}` bevat. Gebruik hier nooit een geheime API-sleutel; gegevens in een browserkaart zijn publiek zichtbaar.

Ondersteund: XYZ-rastertegels van 256 of 512 pixels. Vectorstijlen en WMS-adressen vragen een andere integratie. De bronvermelding ondersteunt veilige HTTPS-links met `<a href="https://…">…</a>`. **OpenStreetMap herstellen** zet alleen de tegelinstellingen terug, niet de beheerpakketlinks. Ongeldige opgeslagen tegelinstellingen vallen bij weergave terug op OpenStreetMap; een netwerkstoring bij een geldige provider veroorzaakt geen automatische providerwissel.

## Shortcodes

- `[perceelscheck]`
- `[perceelscheck_open_grasland]`
- `[perceelscheck_open_akkerland]`
- `[perceelscheck_dooradering]`
- `[perceelscheck_water_klimaat]`

Gebruik bij voorkeur één Perceelscheck per pagina. De specifieke shortcodes wijzigen alleen welke lagen bij aanvang actief zijn.

## Ontwikkeling en controle

Voer vanuit de pluginmap uit:

```bash
npm test
npm run lint:js
```

Controleer PHP daarnaast met `php -l` en WordPress Coding Standards zodra een WordPress-ontwikkelomgeving beschikbaar is. Een release hoort ook handmatig te worden getest op desktop en mobiel, inclusief alle vijf shortcodes, adreszoeken, kaartklikken, uploaden, activeren en terugvallen.

`tests/selection-regression.mjs` voert de volledige selectie-, kaartweergave- en resultaatmodules samen uit met vervangingen aan de browser-, MapLibre- en netwerkgrenzen. Het controleert smalle/brede kaartvlakken, veranderende paneelhoogte, selectie → geen resultaat → timeout → opnieuw zoeken, dubbele acties en gescheiden kaartinstanties. Dit vervangt geen echte responsive browsertest; die blijft onderdeel van de handmatige acceptatie.

De lokale ontwikkelomgeving bevat `test-backend.mjs`. Dit start een tijdelijke WordPress-installatie op poort 9401, test echte uploads, activatie, rollback, integriteit, noncecontrole en tegelinstellingen, en sluit die installatie daarna af. De gebruikersomgeving op 9400 blijft behouden. Standaard gebruikt de test herkenbare synthetische datasets. Met `AND_SOURCE_ARCHIVE` kunnen de afzonderlijke oorspronkelijke Water- en Klimaatbestanden worden gebruikt; hun velden `WATERNATUURTYPE` en `KLIMAATNATUURTYPE` worden alleen in het testgeheugen genormaliseerd.

Nieuwe uploads krijgen formaatmarkering `separate-v1` en jaarneutrale JavaScript-namen. Bestaande gecombineerde versies en de eerdere afzonderlijke 2026-namen blijven ondersteund. Deze migratie herschrijft geen bronbestanden.

## Privacy en juridisch

De plugin bewaart geen zoekopdrachten of geselecteerde adressen. De browser stuurt zoekopdrachten en coördinaten wel naar PDOK en haalt kaarttegels op bij OpenStreetMap. Beschrijf dit in de privacyverklaring. Laat de bronvermeldingen zichtbaar en presenteer perceelgrenzen en resultaten uitsluitend als indicatief.

## Licenties

- Plugin: GPL-2.0-or-later.
- MapLibre GL JS: BSD-3-Clause; licentie meegeleverd onder `vendor/maplibre/`.
- Turf.js: MIT; licentie meegeleverd onder `vendor/turf/`.
- Lora en Open Sans: SIL Open Font License; lettertypen en licenties onder `assets/fonts/`. Geen externe fontaanvragen.
