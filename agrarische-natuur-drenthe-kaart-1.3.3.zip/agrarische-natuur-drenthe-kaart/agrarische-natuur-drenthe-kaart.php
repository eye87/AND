<?php
/**
 * Plugin Name: Agrarische Natuur Drenthe – Perceelscheck
 * Description: Interactieve kaart en perceelscheck met beheerbare kaartversies en beheerpakketlinks.
 * Version: 1.3.3
 * Author: Eye Entertainment
 * Author URI: https://eyeentertainment.nl
 * Text Domain: and-perceelscheck
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AND_KAART_VERSION', '1.3.3' );
define( 'AND_KAART_FILE', __FILE__ );
define( 'AND_KAART_DIR', plugin_dir_path( __FILE__ ) );
define( 'AND_KAART_URL', plugin_dir_url( __FILE__ ) );

require_once AND_KAART_DIR . 'includes/class-and-kaart-plugin.php';

register_activation_hook( __FILE__, array( 'AND_Kaart_Plugin', 'activate' ) );
AND_Kaart_Plugin::instance();
