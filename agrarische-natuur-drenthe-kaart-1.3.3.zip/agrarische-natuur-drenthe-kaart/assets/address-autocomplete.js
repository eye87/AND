/* Accessible address suggestions for one Perceelscheck instance. */
window.ANDPerceelscheck = window.ANDPerceelscheck || {};
window.ANDPerceelscheck.createAddressAutocomplete = function ({
  input, list, pdok, onSubmit, delayMs = 300, minLength = 3
}) {
  let timer = null;
  let requestNumber = 0;
  let suggestions = [];
  let activeIndex = -1;

  function setExpanded(expanded) {
    list.hidden = !expanded;
    input.setAttribute("aria-expanded", String(expanded));
    if (!expanded) {
      activeIndex = -1;
      input.removeAttribute("aria-activedescendant");
    }
  }

  function close() {
    clearTimeout(timer);
    requestNumber += 1;
    suggestions = [];
    list.replaceChildren();
    list.removeAttribute("aria-busy");
    setExpanded(false);
  }

  function activate(index) {
    if (!suggestions.length) return;
    activeIndex = (index + suggestions.length) % suggestions.length;
    [...list.children].forEach((option, optionIndex) => {
      const active = optionIndex === activeIndex;
      option.classList.toggle("active", active);
      option.setAttribute("aria-selected", String(active));
      if (active) {
        input.setAttribute("aria-activedescendant", option.id);
        option.scrollIntoView?.({ block: "nearest" });
      }
    });
  }

  function choose(index) {
    const suggestion = suggestions[index];
    if (!suggestion) return;
    input.value = suggestion.label;
    close();
    onSubmit();
  }

  function render(items) {
    suggestions = items;
    activeIndex = -1;
    list.replaceChildren();
    items.forEach((suggestion, index) => {
      const option = document.createElement("li");
      option.id = `${list.id}-option-${index}`;
      option.className = "address-suggestion";
      option.setAttribute("role", "option");
      option.setAttribute("aria-selected", "false");
      option.textContent = suggestion.label;
      option.addEventListener("pointerdown", event => event.preventDefault());
      option.addEventListener("click", () => choose(index));
      list.appendChild(option);
    });
    setExpanded(items.length > 0);
  }

  async function updateSuggestions(query, currentRequest) {
    list.setAttribute("aria-busy", "true");
    try {
      const items = await pdok.suggestAddresses(query);
      if (currentRequest !== requestNumber || input.value.trim() !== query) return;
      render(items);
    } catch (error) {
      // Suggestions are an enhancement; the regular search must remain usable.
      if (currentRequest === requestNumber) close();
    } finally {
      if (currentRequest === requestNumber) list.removeAttribute("aria-busy");
    }
  }

  input.addEventListener("input", () => {
    clearTimeout(timer);
    requestNumber += 1;
    const query = input.value.trim();
    if (query.length < minLength) {
      close();
      return;
    }
    const currentRequest = requestNumber;
    timer = setTimeout(() => updateSuggestions(query, currentRequest), delayMs);
  });

  input.addEventListener("keydown", event => {
    if (event.key === "ArrowDown" && suggestions.length) {
      event.preventDefault();
      activate(activeIndex + 1);
    } else if (event.key === "ArrowUp" && suggestions.length) {
      event.preventDefault();
      activate(activeIndex - 1);
    } else if (event.key === "Escape") {
      close();
    } else if (event.key === "Enter") {
      event.preventDefault();
      if (!list.hidden && activeIndex >= 0) choose(activeIndex);
      else {
        close();
        onSubmit();
      }
    }
  });

  input.addEventListener("blur", () => {
    setTimeout(() => {
      if (!list.contains(document.activeElement)) close();
    }, 0);
  });

  return { close };
};
