/* Per-map instance; dependencies are supplied explicitly by the coordinator. */
window.ANDPerceelscheck = window.ANDPerceelscheck || {};
window.ANDPerceelscheck.createDatasets = function ({ geometry, dataUrls, anlbByCategory, waterSources, categories }) {
    const featureBounds = new WeakMap();

    function normalizeText(value) {
      return String(value ?? "")
        .toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .replace(/[_-]+/g, " ")
        .replace(/\s+/g, " ")
        .trim();
    }

    function detectCategory(feature) {
      const props = feature.properties || {};

      // De officiële Drenthe-WFS codeert het agrarische natuurtype met
      // Index Natuur en Landschap-codes, bijvoorbeeld A15 voor Dooradering.
      // We gebruiken daarom primair het veld agrarischNatuurType.
      const rawCode = String(props.agrarischNatuurType || "").trim().toUpperCase();

      // Sommige datasets kunnen een subcode teruggeven (bijv. A15.01).
      // Daarom vergelijken we op de hoofdcode vóór de punt.
      const code = rawCode.split(".")[0];

      if (code === "A11") return "grasland";     // Open grasland
      if (code === "A12") return "akkerland";   // Open akkerland
      if (code === "A15") return "dooradering"; // Dooradering

      // Op de website worden Water en Klimaat als één keuze gepresenteerd.
      if (code === "W01" || code === "K01") return "water";

      // Robuuste fallback voor het geval een toekomstige versie tekstlabels bevat.
      const values = Object.values(props)
        .filter(value => value !== null && value !== undefined)
        .map(normalizeText);

      const text = values.join(" | ");

      if (text.includes("open grasland") || text.includes("grasland")) {
        return "grasland";
      }

      if (
        text.includes("open akkerland") ||
        text.includes("open akker") ||
        text.includes("akkerland")
      ) {
        return "akkerland";
      }

      if (text.includes("dooradering")) {
        return "dooradering";
      }

      if (
        text.includes("water en klimaat") ||
        text.includes("water & klimaat") ||
        text.includes("water/klimaat") ||
        text.includes("klimaat") ||
        /\bwater\b/.test(text)
      ) {
        return "water";
      }

      return null;
    }

    function loadInlineAgrarisch() {
      const data = window.ANLB_AGRARISCH_DATA || window.ANLB_AGRARISCH_2026;

      if (!data || !Array.isArray(data.features)) {
        throw new Error("De ingebakken kaartdata bevat geen geldige GeoJSON FeatureCollection.");
      }

      const unknown = [];

      data.features.forEach(feature => {
        const category = detectCategory(feature);

        if (category) {
          feature.properties = {
            ...(feature.properties || {}),
            _anlb_category: category
          };
          anlbByCategory[category].features.push(feature);
        } else {
          unknown.push(feature);
        }
      });

      return { total: data.features.length, unknown: unknown.length };
    }

    function loadInlineWaterClimate() {
      const datasets = dataUrls.climate
        ? [
          ["water", window.ANLB_WATER_DATA || window.ANLB_WATER_2026],
          ["climate", window.ANLB_KLIMAAT_DATA || window.ANLB_KLIMAAT_2026]
        ]
        : [["water", window.ANLB_WATER_KLIMAAT_2026]];
      let total = 0;

      datasets.forEach(([sourceKey, data]) => {
        if (!data || !Array.isArray(data.features)) {
          throw new Error(`Het databestand voor ${sourceKey === "climate" ? "Klimaat" : "Water"} ontbreekt of is ongeldig.`);
        }
        waterSources[sourceKey] = data;
        data.features.forEach(feature => {
          feature.properties = {
            ...(feature.properties || {}),
            _anlb_category: "water"
          };
          anlbByCategory.water.features.push(feature);
        });
        total += data.features.length;
      });

      return { total };
    }

    function indexFeatureBounds() {
      Object.values(anlbByCategory).forEach(collection => {
        collection.features.forEach(feature => {
          featureBounds.set(feature, geometry.bounds(feature.geometry));
        });
      });
    }

    function safeBooleanIntersects(a, b) {
      try {
        return turf.booleanIntersects(a, b);
      } catch (error) {
        console.warn("Intersectiecontrole mislukt voor feature:", error);
        throw new Error("De overlap kon niet betrouwbaar worden berekend.");
      }
    }

    function checkParcelAgainstAnlb(parcelFeature) {
      const parcelBounds = geometry.bounds(parcelFeature.geometry);

      return Object.entries(anlbByCategory).map(([key, fc]) => {
        let hitCount = 0;

        for (const anlbFeature of fc.features) {
          const anlbBounds = featureBounds.get(anlbFeature);
          if (anlbBounds && !geometry.boundsIntersect(parcelBounds, anlbBounds)) {
            continue;
          }
          if (safeBooleanIntersects(parcelFeature, anlbFeature)) {
            hitCount++;
          }
        }

        return {
          key,
          label: categories[key].label,
          url: categories[key].url,
          overlaps: hitCount > 0,
          hitCount
        };
      });
    }

    return { normalizeText, detectCategory, loadInlineAgrarisch, loadInlineWaterClimate, indexFeatureBounds, safeBooleanIntersects, checkParcelAgainstAnlb };
};
