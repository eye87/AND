(function exposeGeometryUtilities(global) {
  "use strict";

  function pointInRing(point, ring) {
    const [x, y] = point;
    let inside = false;

    for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
      const [xi, yi] = ring[i];
      const [xj, yj] = ring[j];
      const intersects =
        ((yi > y) !== (yj > y)) &&
        (x < ((xj - xi) * (y - yi)) / ((yj - yi) || Number.EPSILON) + xi);
      if (intersects) inside = !inside;
    }
    return inside;
  }

  function pointInPolygonGeometry(point, geometry) {
    if (!geometry) return false;

    const polygonContains = polygon => {
      if (!polygon?.length || !pointInRing(point, polygon[0])) return false;
      return !polygon.slice(1).some(ring => pointInRing(point, ring));
    };

    if (geometry.type === "Polygon") {
      return polygonContains(geometry.coordinates);
    }
    if (geometry.type === "MultiPolygon") {
      return geometry.coordinates.some(polygonContains);
    }
    return false;
  }

  function polygonsOf(geometry) {
    if (geometry.type === "Polygon") return [geometry.coordinates];
    if (geometry.type === "MultiPolygon") return geometry.coordinates;
    return [];
  }

  function bounds(geometry) {
    let minLng = Infinity;
    let minLat = Infinity;
    let maxLng = -Infinity;
    let maxLat = -Infinity;

    polygonsOf(geometry).forEach(polygon => {
      polygon.forEach(ring => {
        ring.forEach(([lng, lat]) => {
          minLng = Math.min(minLng, lng);
          minLat = Math.min(minLat, lat);
          maxLng = Math.max(maxLng, lng);
          maxLat = Math.max(maxLat, lat);
        });
      });
    });
    return { minLng, minLat, maxLng, maxLat };
  }

  function boundsIntersect(a, b) {
    return !(
      a.maxLng < b.minLng ||
      a.minLng > b.maxLng ||
      a.maxLat < b.minLat ||
      a.minLat > b.maxLat
    );
  }

  global.ANDGeometry = Object.freeze({
    bounds,
    boundsIntersect,
    pointInPolygonGeometry
  });
})(window);
