/* Per-map instance; dependencies are supplied explicitly by the coordinator. */
window.ANDPerceelscheck = window.ANDPerceelscheck || {};
window.ANDPerceelscheck.createMapView = function ({ map, appRoot, geometry, categories, activeLayers, waterSources, anlbByCategory, parcelMunicipality, parcelSection, parcelNumber, parcelArea, parcelSummary, parcelCard }) {
    let addressMarker = null;

    function addAnlbLayers(keys) {
      keys.forEach(key => {
        if (map.getSource(`anlb-${key}`)) return;
        const categoryKey = key === "climate" ? "water" : key;
        const config = categories[categoryKey];
        const sourceId = `anlb-${key}`;
        const fillId = `anlb-${key}-fill`;
        const lineId = `anlb-${key}-line`;

        map.addSource(sourceId, {
          type: "geojson",
          data: waterSources[key] || anlbByCategory[key]
        });

        map.addLayer({
          id: fillId,
          type: "fill",
          source: sourceId,
          layout: {
            visibility: activeLayers.has(categoryKey) ? "visible" : "none"
          },
          paint: {
            "fill-color": config.color,
            "fill-opacity": config.fillOpacity ?? 0.48
          }
        });

        map.addLayer({
          id: lineId,
          type: "line",
          source: sourceId,
          layout: {
            visibility: activeLayers.has(categoryKey) ? "visible" : "none"
          },
          paint: {
            "line-color": config.color,
            "line-width": 1.35,
            "line-opacity": 0.95
          }
        });
      });
    }

    function addProvinceBase() {
      if (!window.PROVINCIE_DRENTHE) return;

      map.addSource("province-drenthe", {
        type: "geojson",
        data: window.PROVINCIE_DRENTHE
      });

      const geometry = window.PROVINCIE_DRENTHE.features[0]?.geometry;
      const polygons = geometry?.type === "MultiPolygon"
        ? geometry.coordinates
        : geometry?.type === "Polygon"
          ? [geometry.coordinates]
          : [];

      if (!polygons.length) return;

      const mask = {
        type: "Feature",
        properties: {},
        geometry: {
          type: "Polygon",
          coordinates: [
            [[5.0, 51.8], [8.0, 51.8], [8.0, 54.0], [5.0, 54.0], [5.0, 51.8]],
            ...polygons.map(polygon => polygon[0])
          ]
        }
      };

      map.addSource("outside-drenthe", {
        type: "geojson",
        data: mask
      });

      map.addLayer({
        id: "outside-drenthe-fade",
        type: "fill",
        source: "outside-drenthe",
        paint: {
          "fill-color": "#f5f6f3",
          "fill-opacity": 0.62
        }
      });
    }

    function addProvinceOutline() {
      if (!map.getSource("province-drenthe")) return;

      map.addLayer({
        id: "province-drenthe-outline-halo",
        type: "line",
        source: "province-drenthe",
        paint: {
          "line-color": "rgba(255,255,255,.92)",
          "line-width": 7
        }
      });

      map.addLayer({
        id: "province-drenthe-outline",
        type: "line",
        source: "province-drenthe",
        paint: {
          "line-color": "#2f6f3e",
          "line-width": 4,
          "line-opacity": 1
        }
      });
    }

    // Use the largest clear rectangle beside the actual panel, not a breakpoint
    // assumption. This also handles a narrow map embedded in a wide desktop page.
    function cameraPadding() {
      const canvas = map.getContainer().getBoundingClientRect();
      const width = Math.max(1, canvas.width);
      const height = Math.max(1, canvas.height);
      const gap = Math.min(32, width / 10, height / 10);
      const padding = { top: gap, right: gap, bottom: gap, left: gap };
      const panel = appRoot.querySelector(".panel")?.getBoundingClientRect();
      if (panel?.width && panel.height && panel.right > canvas.left &&
          panel.left < canvas.right && panel.bottom > canvas.top && panel.top < canvas.bottom) {
        const candidates = [
          { side: "right", free: Math.max(0, panel.left - canvas.left), length: width, span: height },
          { side: "left", free: Math.max(0, canvas.right - panel.right), length: width, span: height },
          { side: "bottom", free: Math.max(0, panel.top - canvas.top), length: height, span: width },
          { side: "top", free: Math.max(0, canvas.bottom - panel.bottom), length: height, span: width }
        ];
        candidates.sort((a, b) => b.free * b.span - a.free * a.span);
        const best = candidates[0];
        // Always leave a positive viewport, even when a theme covers most of the map.
        const reserve = Math.min(best.length - best.free + gap, best.length * 0.8);
        padding[best.side] = Math.max(gap, reserve);
      }
      return padding;
    }

    function fitInitialProvinceView() {

      map.fitBounds(
        [[6.11982, 52.612198], [7.09274, 53.203821]],
        {
          padding: cameraPadding(),
          duration: 0
        }
      );
    }

    function setCategoryVisibility(key, visible) {
      if (visible) activeLayers.add(key);
      else activeLayers.delete(key);
      const keys = key === "water" ? ["water", "climate"] : [key];
      keys.flatMap(sourceKey => [`anlb-${sourceKey}-fill`, `anlb-${sourceKey}-line`]).forEach(id => {
        if (map.getLayer(id)) {
          map.setLayoutProperty(id, "visibility", visible ? "visible" : "none");
        }
      });
    }

    function pointIsInsideDrenthe(point) {
      const features = window.PROVINCIE_DRENTHE?.features || [];
      return features.some(feature =>
        geometry.pointInPolygonGeometry([point.lng, point.lat], feature.geometry)
      );
    }

    function renderParcel(feature, options = {}) {
      const fc = {
        type: "FeatureCollection",
        features: [feature]
      };

      if (map.getSource("selected-parcel")) {
        map.getSource("selected-parcel").setData(fc);
      } else {
        map.addSource("selected-parcel", {
          type: "geojson",
          data: fc
        });

        map.addLayer({
          id: "selected-parcel-fill",
          type: "fill",
          source: "selected-parcel",
          paint: {
            "fill-color": "#ffffff",
            "fill-opacity": 0.20
          }
        });

        map.addLayer({
          id: "selected-parcel-outline",
          type: "line",
          source: "selected-parcel",
          paint: {
            "line-color": "#111827",
            "line-width": 3
          }
        });
      }

      const p = feature.properties || {};

      parcelMunicipality.textContent =
        p.kadastrale_gemeente_waarde ||
        p.akr_kadastrale_gemeente_code_waarde ||
        "–";

      parcelSection.textContent = p.sectie || "–";
      parcelNumber.textContent = p.perceelnummer ?? "–";

      const area = Number(p.kadastrale_grootte_waarde);
      parcelArea.textContent = Number.isFinite(area)
        ? new Intl.NumberFormat("nl-NL").format(area) + " m²"
        : "–";

      parcelSummary.textContent =
        `Perceel ${parcelMunicipality.textContent} ${parcelSection.textContent} ${parcelNumber.textContent}` +
        ` · ${parcelArea.textContent}`;

      parcelCard.classList.add("visible");

      // Measure after the result/card content is visible: its height can change.
      if (!options.preserveView) {
        const b = geometry.bounds(feature.geometry);
        map.fitBounds(
          [[b.minLng, b.minLat], [b.maxLng, b.maxLat]],
          { padding: cameraPadding(), maxZoom: options.maxZoom ?? 18 }
        );
      }
    }

    function clearSelection() {
      map.stop();
      map.getSource("selected-parcel")?.setData({ type: "FeatureCollection", features: [] });
      if (addressMarker) addressMarker.remove();
      addressMarker = null;
    }

    function placeAddressMarker(point) {
      if (addressMarker) addressMarker.remove();

      const el = document.createElement("div");
      el.className = "address-marker";
      el.setAttribute("aria-label", "Gezocht adres");

      const pin = document.createElement("div");
      pin.className = "address-marker-pin";

      const center = document.createElement("span");
      center.className = "address-marker-center";
      pin.appendChild(center);
      el.appendChild(pin);

      addressMarker = new maplibregl.Marker({ element: el, anchor: "bottom" })
        .setLngLat([point.lng, point.lat])
        .addTo(map);
    }

    return { addAnlbLayers, addProvinceBase, addProvinceOutline, fitInitialProvinceView, setCategoryVisibility, pointIsInsideDrenthe, renderParcel, placeAddressMarker, clearSelection };
};
