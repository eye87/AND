/* Compact search presentation and accessible layer popover. */
window.ANDPerceelscheck = window.ANDPerceelscheck || {};
window.ANDPerceelscheck.createMobileControls = function ({
  appRoot, addressInput, layersToggle, layerList
}) {
  const mediaQuery = window.matchMedia("(max-width: 1024px)");
  let open = false;

  function setOpen(nextOpen, returnFocus = false) {
    open = Boolean(nextOpen && mediaQuery.matches);
    layersToggle.setAttribute("aria-expanded", String(open));
    layersToggle.setAttribute("aria-label", open ? "Kaartlagen sluiten" : "Kaartlagen openen");
    layerList.classList.toggle("mobile-open", open);
    if (!open && returnFocus) layersToggle.focus();
  }

  function updateMode() {
    if (!mediaQuery.matches) setOpen(false);
  }

  layersToggle.addEventListener("click", () => setOpen(!open));

  document.addEventListener("click", event => {
    if (!open || layersToggle.contains(event.target) || layerList.contains(event.target)) return;
    setOpen(false);
    // Closing the menu on the map should not also select a parcel.
    if (event.target.closest?.(".anlb-map") && appRoot.contains(event.target)) {
      event.preventDefault();
      event.stopPropagation();
    }
  }, true);

  document.addEventListener("keydown", event => {
    if (open && event.key === "Escape") {
      event.preventDefault();
      setOpen(false, true);
    }
  });

  if (typeof mediaQuery.addEventListener === "function") {
    mediaQuery.addEventListener("change", updateMode);
  } else {
    mediaQuery.addListener(updateMode);
  }
  updateMode();

  return { close: () => setOpen(false) };
};
