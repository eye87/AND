/* Per-map instance; dependencies are supplied explicitly by the coordinator. */
window.ANDPerceelscheck = window.ANDPerceelscheck || {};
window.ANDPerceelscheck.createPdok = function ({ geometry, timeoutMs = 15000 }) {
    const pdokSearchUrl = "https://api.pdok.nl/bzk/locatieserver/search/v3_1/free";
    const pdokSuggestUrl = "https://api.pdok.nl/bzk/locatieserver/search/v3_1/suggest";
    const pdokReverseUrl = "https://api.pdok.nl/bzk/locatieserver/search/v3_1/reverse";
    const parcelItemsUrl = "https://api.pdok.nl/kadaster/brk-kadastrale-kaart/ogc/v1/collections/perceel/items";

    // Bound the entire response, including its JSON body. Abort releases network work;
    // the race also guarantees recovery if a transport does not honour cancellation.
    async function requestJson(url) {
      const controller = new AbortController();
      let timer;
      const deadline = new Promise((resolve, reject) => {
        timer = setTimeout(() => {
          const error = new Error("PDOK reageert niet op tijd. Probeer het opnieuw.");
          error.code = "PDOK_TIMEOUT";
          reject(error);
          controller.abort();
        }, timeoutMs);
      });
      try {
        return await Promise.race([
          (async () => {
            const response = await fetch(url, {
              headers: { Accept: "application/geo+json, application/json" },
              signal: controller.signal
            });
            if (!response.ok) throw new Error("PDOK gaf geen geldig antwoord. Probeer het opnieuw.");
            return await response.json();
          })(),
          deadline
        ]);
      } finally {
        clearTimeout(timer);
      }
    }

    function parsePointWkt(wkt) {
      if (!wkt) return null;
      const match = String(wkt).match(/POINT\s*\(\s*([-\d.]+)\s+([-\d.]+)\s*\)/i);
      if (!match) return null;

      return {
        lng: Number(match[1]),
        lat: Number(match[2])
      };
    }

    function isInDrenthe(doc) {
      return String(doc.provincienaam || "").toLowerCase().includes("drenthe");
    }

    async function suggestAddresses(query) {
      const url = new URL(pdokSuggestUrl);
      url.searchParams.set("q", query);
      url.searchParams.set("rows", "8");
      url.searchParams.append("fq", "provincienaam:Drenthe");

      const data = await requestJson(url);
      const docs = data?.response?.docs || [];
      const allowedTypes = new Set(["adres", "postcode", "weg", "woonplaats"]);
      const seen = new Set();

      return docs.reduce((items, doc) => {
        const type = String(doc.type || "").toLowerCase();
        const label = String(doc.weergavenaam || "").trim();
        if (!label || (type && !allowedTypes.has(type))) return items;
        const key = label.toLocaleLowerCase("nl");
        if (seen.has(key)) return items;
        seen.add(key);
        items.push({ label, type, id: String(doc.id || "") });
        return items;
      }, []);
    }

    async function findAddress(query) {
      const url = new URL(pdokSearchUrl);
      url.searchParams.set("q", query);
      url.searchParams.set("rows", "15");

      const data = await requestJson(url);
      const docs = data?.response?.docs || [];
      const drentheDocs = docs.filter(isInDrenthe);

      const doc =
        drentheDocs.find(item => item.type === "adres") ||
        drentheDocs.find(item => item.type === "postcode") ||
        drentheDocs[0];

      if (!doc) return null;

      const point = parsePointWkt(doc.centroide_ll);

      if (!point || !Number.isFinite(point.lat) || !Number.isFinite(point.lng)) {
        return null;
      }

      return { doc, point };
    }

    async function reverseGeocode(point) {
      const url = new URL(pdokReverseUrl);
      url.searchParams.set("lat", point.lat);
      url.searchParams.set("lon", point.lng);
      url.searchParams.set("type", "adres");
      url.searchParams.set("distance", "500");
      url.searchParams.set("rows", "1");
      url.searchParams.set(
        "fl",
        "weergavenaam postcode woonplaatsnaam gemeentenaam provincienaam type afstand"
      );

      const data = await requestJson(url);
      const doc = data?.response?.docs?.[0];
      return doc && isInDrenthe(doc) ? doc : null;
    }

    async function findParcelAtPoint(point) {
      const deltas = [0.00005, 0.00025, 0.0007];

      for (const delta of deltas) {
        const url = new URL(parcelItemsUrl);

        url.searchParams.set(
          "bbox",
          `${point.lng - delta},${point.lat - delta},${point.lng + delta},${point.lat + delta}`
        );
        url.searchParams.set("limit", "100");
        url.searchParams.set("f", "json");

        const data = await requestJson(url);
        const features = Array.isArray(data?.features) ? data.features : [];

        const containing = features.find(feature =>
          geometry.pointInPolygonGeometry([point.lng, point.lat], feature.geometry)
        );

        if (containing) return containing;

      }

      return null;
    }

    return { parsePointWkt, isInDrenthe, suggestAddresses, findAddress, reverseGeocode, findParcelAtPoint };
};
