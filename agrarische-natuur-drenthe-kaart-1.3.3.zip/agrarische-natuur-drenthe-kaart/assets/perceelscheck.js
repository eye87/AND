if (document.querySelector(".anlb-perceelscheck")) {
  document.body.classList.add("anlb-has-perceelscheck");
}

document.querySelectorAll(".anlb-perceelscheck").forEach(initPerceelscheck);

function initPerceelscheck(appRoot) {
    const geometry = window.ANDGeometry;
    if (!geometry) throw new Error("De geometriehulpfuncties zijn niet geladen.");
    const config = JSON.parse(appRoot.dataset.config || "{}");
    const packageUrls = config.packageUrls || {};
    const dataUrls = config.dataUrls || {};
    const allowedDataOrigins = new Set([
      window.location.origin,
      ...(Array.isArray(config.dataOrigins) ? config.dataOrigins : [])
    ]);
    const tileSource = config.tileSource || {};
    const activeLayers = new Set(config.activeLayers || ["grasland", "akkerland", "dooradering", "water"]);

    const categories = {
      grasland: {
        label: "Open grasland",
        color: "#287f78",
        url: packageUrls.grasland || "#"
      },
      akkerland: {
        label: "Open akkerland",
        color: "#d5a85c",
        url: packageUrls.akkerland || "#"
      },
      dooradering: {
        label: "Dooradering",
        color: "#ad7074",
        url: packageUrls.dooradering || "#"
      },
      water: {
        label: "Water en klimaat",
        color: "#3973b7",
        fillOpacity: 0.32,
        url: packageUrls.water || "#"
      }
    };

    const emptyFc = () => ({ type: "FeatureCollection", features: [] });

    let anlbByCategory = {
      grasland: emptyFc(),
      akkerland: emptyFc(),
      dooradering: emptyFc(),
      water: emptyFc()
    };

    // Preserve provenance while presenting one combined category to visitors.
    const waterSources = {};

    let anlbLoaded = false;
    let mapClickBlockedUntil = 0;

    const map = new maplibregl.Map({
      container: appRoot.querySelector(".anlb-map"),
      style: {
        version: 8,
        sources: {
          osm: {
            type: "raster",
            tiles: [tileSource.url || "https://tile.openstreetmap.org/{z}/{x}/{y}.png"],
            tileSize: tileSource.tileSize === 512 ? 512 : 256,
            attribution: tileSource.attribution || "© OpenStreetMap-bijdragers"
          }
        },
        layers: [
          {
            id: "osm",
            type: "raster",
            source: "osm",
            paint: {
              "raster-opacity": 0.78,
              "raster-saturation": -0.18
            }
          }
        ]
      },
      center: [6.60, 52.95],
      zoom: 8.63,
      minZoom: 7,
      maxZoom: 19,
      clickTolerance: 5,
      maxBounds: [
        [5.75, 52.40],
        [7.45, 53.38]
      ]
    });

    map.addControl(
      new maplibregl.NavigationControl({
        showCompass: false,
        showZoom: true
      }),
      "top-left"
    );

    const dataStatus = appRoot.querySelector(".data-status");
    const addressInput = appRoot.querySelector(".address-input");
    const addressClear = appRoot.querySelector(".address-clear");
    const addressSuggestions = appRoot.querySelector(".address-suggestions");
    const layersToggle = appRoot.querySelector(".mobile-layers-toggle");
    const layerList = appRoot.querySelector(".layer-list");
    const searchBtn = appRoot.querySelector(".search-button");
    const searchStatus = appRoot.querySelector(".search-status");

    const locationName = appRoot.querySelector(".location-name");
    const locationMeta = appRoot.querySelector(".location-meta");

    const parcelCard = appRoot.querySelector(".parcel-card");
    const parcelSummary = appRoot.querySelector(".parcel-summary-meta");
    const parcelMunicipality = appRoot.querySelector(".parcel-municipality");
    const parcelSection = appRoot.querySelector(".parcel-section");
    const parcelNumber = appRoot.querySelector(".parcel-number");
    const parcelArea = appRoot.querySelector(".parcel-area");

    const resultBox = appRoot.querySelector(".result-box");
    const resultTitle = appRoot.querySelector(".result-title");
    const resultList = appRoot.querySelector(".result-list");
    const checkboxes = [...appRoot.querySelectorAll("[data-layer]")];

    const { loadInlineAgrarisch, loadInlineWaterClimate, indexFeatureBounds, checkParcelAgainstAnlb } = window.ANDPerceelscheck.createDatasets({
      geometry, dataUrls, anlbByCategory, waterSources, categories
    });
    const view = window.ANDPerceelscheck.createMapView({
      map, appRoot, geometry, categories, activeLayers, waterSources, anlbByCategory, parcelMunicipality, parcelSection, parcelNumber, parcelArea, parcelSummary, parcelCard
    });
    const { addAnlbLayers, addProvinceBase, addProvinceOutline, fitInitialProvinceView, setCategoryVisibility, pointIsInsideDrenthe } = view;
    const pdok = window.ANDPerceelscheck.createPdok({
      geometry
    });
    const { renderResults } = window.ANDPerceelscheck.createResultsView({
      resultList, resultTitle, resultBox
    });

    const { searchAndCheckParcel, selectPointOnMap } = window.ANDPerceelscheck.createSelectionController({
      isReady: () => anlbLoaded, map, view, pdok, checkParcelAgainstAnlb, renderResults,
      addressInput, searchBtn, searchStatus, locationName, locationMeta,
      parcelCard, parcelSummary, parcelMunicipality, parcelSection, parcelNumber,
      parcelArea, resultBox, resultTitle, resultList
    });
    const addressAutocomplete = window.ANDPerceelscheck.createAddressAutocomplete({
      input: addressInput,
      list: addressSuggestions,
      pdok,
      onSubmit: searchAndCheckParcel
    });
    const mobileControls = window.ANDPerceelscheck.createMobileControls({
      appRoot,
      addressInput,
      layersToggle,
      layerList
    });

    addressClear?.addEventListener("click", () => {
      addressInput.value = "";
      addressInput.dispatchEvent(new Event("input", { bubbles: true }));
      addressInput.focus();
    });

    function loadDataScript(url) {
      return new Promise((resolve, reject) => {
        let parsedUrl;
        try {
          parsedUrl = new URL(url, window.location.href);
        } catch (error) {
          reject(new Error("Ongeldige URL voor kaartdata."));
          return;
        }
        if (!url || !allowedDataOrigins.has(parsedUrl.origin) || !/^https?:$/i.test(parsedUrl.protocol)) {
          reject(new Error("Ongeldige URL voor kaartdata."));
          return;
        }
        const script = document.createElement("script");
        script.src = parsedUrl.href;
        script.async = true;
        const finish = error => {
          clearTimeout(timer);
          script.onload = script.onerror = null;
          if (error) {
            script.remove();
            reject(error);
          } else resolve();
        };
        const timer = setTimeout(() => finish(new Error("Het laden van de kaartdata duurt te lang. Vernieuw de pagina.")), 60000);
        script.onload = () => finish();
        script.onerror = () => finish(new Error(`Kaartbestand kon niet worden geladen: ${url}`));
        document.head.appendChild(script);
      });
    }

    function setLayerLoadState(keys, state, text) {
      keys.forEach(key => {
        const row = appRoot.querySelector(`[data-layer-row="${key}"]`);
        const label = row?.querySelector(".layer-load-state");
        if (row) row.dataset.loadState = state;
        if (label) label.textContent = text || "";
      });
    }

    map.on("load", () => {
      try {
        addProvinceBase();
        addProvinceOutline();
        fitInitialProvinceView();

        setLayerLoadState(["grasland", "akkerland", "dooradering"], "loading", "wordt geladen…");
        setLayerLoadState(["water"], "loading", "wordt geladen…");

        // Start beide downloads direct. Agrarisch wordt bewust als eerste verwerkt.
        const agrarischDownload = loadDataScript(dataUrls.agrarisch);
        const waterDownloads = [loadDataScript(dataUrls.water)];
        if (dataUrls.climate) waterDownloads.push(loadDataScript(dataUrls.climate));
        const waterDownload = Promise.all(waterDownloads);

        const agrarischReady = agrarischDownload.then(() => {
          const result = loadInlineAgrarisch();
          if (!Object.values(anlbByCategory).some(fc => fc.features.length)) {
            throw new Error("De agrarische categorieën konden niet worden herkend.");
          }
          addAnlbLayers(["grasland", "akkerland", "dooradering"]);
          setLayerLoadState(["grasland", "akkerland", "dooradering"], "ready", "");
          return result;
        }).catch(error => {
          setLayerLoadState(["grasland", "akkerland", "dooradering"], "error", "laden mislukt");
          throw error;
        });

        const waterReady = Promise.all([agrarischReady, waterDownload]).then(() => {
          loadInlineWaterClimate();
          addAnlbLayers(Object.keys(waterSources));
          // Water hoort visueel onder de agrarische categorieën.
          Object.keys(waterSources).flatMap(key => [`anlb-${key}-fill`, `anlb-${key}-line`]).forEach(id => {
            if (map.getLayer(id)) map.moveLayer(id, "anlb-grasland-fill");
          });
          setLayerLoadState(["water"], "ready", "");
        }).catch(error => {
          setLayerLoadState(["water"], "error", "laden mislukt");
          throw error;
        });

        Promise.all([agrarischReady, waterReady]).then(() => {
          indexFeatureBounds();
          anlbLoaded = true;
          addressInput.disabled = false;
          searchBtn.disabled = false;
          dataStatus.classList.add("ok");
          dataStatus.textContent = "Gebiedsgegevens geladen.";
          dataStatus.style.display = "none";
          searchStatus.textContent = "";
        }).catch(error => {
          console.error(error);
          dataStatus.classList.add("error");
          dataStatus.textContent = "Niet alle gebiedsgegevens konden worden geladen.";
          dataStatus.style.display = "block";
          searchStatus.textContent = "Vernieuw de pagina of probeer het later opnieuw.";
        });
      } catch (error) {
        console.error(error);
        dataStatus.classList.add("error");
        dataStatus.textContent = "De gebiedsgegevens konden niet worden geladen.";
        dataStatus.style.display = "block";
        searchStatus.textContent =
          "De kaartlagen konden niet worden geladen. Probeer het bestand opnieuw te openen.";
      }
    });

    checkboxes.forEach(checkbox => {
      checkbox.addEventListener("change", () => {
        setCategoryVisibility(checkbox.dataset.layer, checkbox.checked);
      });
    });

    searchBtn.addEventListener("click", () => {
      addressAutocomplete.close();
      mobileControls.close();
      searchAndCheckParcel();
    });

    map.on("dragstart", () => {
      mapClickBlockedUntil = Infinity;
    });

    map.on("dragend", () => {
      mapClickBlockedUntil = performance.now() + 180;
    });

    map.on("click", event => {
      if (performance.now() < mapClickBlockedUntil) return;
      if (!pointIsInsideDrenthe(event.lngLat)) return;
      selectPointOnMap({ lng: event.lngLat.lng, lat: event.lngLat.lat });
    });
}
