/* Per-map instance; dependencies are supplied explicitly by the coordinator. */
window.ANDPerceelscheck = window.ANDPerceelscheck || {};
window.ANDPerceelscheck.createResultsView = function ({ resultList, resultTitle, resultBox }) {
    

    function renderResults(results) {
      resultList.innerHTML = "";
      const overlaps = results.filter(result => result.overlaps);

      resultTitle.textContent = overlaps.length
        ? "Beschikbare beheerpakketten"
        : "Geen beheerpakketten beschikbaar";
      resultBox.classList.toggle("empty", overlaps.length === 0);

      overlaps.forEach(result => {
        const row = document.createElement("div");
        row.className = "result-row";

        const label = document.createElement("span");
        label.textContent = result.label;

        const link = document.createElement("a");
        link.className = "result-link";
        link.href = result.url;
        link.target = "_blank";
        link.rel = "noopener noreferrer";
        link.textContent = "Bekijk beheerpakket";

        row.append(label, link);
        resultList.appendChild(row);
      });

      resultBox.classList.add("visible");
    }

    return { renderResults };
};
