/* One selection workflow per map, shared by address search and map clicks. */
window.ANDPerceelscheck = window.ANDPerceelscheck || {};
window.ANDPerceelscheck.createSelectionController = function ({
  isReady, map, view, pdok, checkParcelAgainstAnlb, renderResults,
  addressInput, searchBtn, searchStatus, locationName, locationMeta,
  parcelCard, parcelSummary, parcelMunicipality, parcelSection, parcelNumber,
  parcelArea, resultBox, resultTitle, resultList
}) {
  let busy = false;

  function resetSelection() {
    view.clearSelection();
    parcelCard.classList.remove("visible");
    parcelCard.open = false;
    resultBox.classList.remove("visible", "empty");
    resultList.textContent = "";
    resultTitle.textContent = "";
    locationName.textContent = "";
    locationMeta.textContent = "";
    parcelSummary.textContent = "";
    [parcelMunicipality, parcelSection, parcelNumber, parcelArea].forEach(el => {
      el.textContent = "–";
    });
  }

  async function runSelection(message, action) {
    if (busy || searchBtn.disabled) return;
    if (!isReady()) {
      searchStatus.textContent = "De officiële ANLb-gebieden zijn nog niet geladen.";
      return;
    }
    busy = true;
    searchBtn.disabled = true;
    try {
      resetSelection();
      searchStatus.textContent = message;
      await action();
    } catch (error) {
      console.error(error);
      // Never leave a partial or previous selection next to a failed result.
      resetSelection();
      searchStatus.textContent = error.code === "PDOK_TIMEOUT"
        ? error.message
        : "De perceelcheck kon niet volledig worden uitgevoerd. Er is geen betrouwbare uitslag beschikbaar. Probeer het later opnieuw.";
    } finally {
      busy = false;
      searchBtn.disabled = !isReady();
    }
  }

  function showLocation(name, meta) {
    locationName.textContent = name;
    locationMeta.textContent = [...new Set(meta.filter(Boolean))].join(" · ");
    parcelSummary.textContent = "Perceel wordt opgezocht…";
    parcelCard.classList.add("visible");
  }

  function completeParcel(parcel, options, missingMessage) {
    if (!parcel) {
      parcelSummary.textContent = "Geen kadastraal perceel gevonden";
      searchStatus.textContent = missingMessage;
      return;
    }
    searchStatus.textContent = "Perceel gevonden. Beheerpakketten worden gecontroleerd…";
    const results = checkParcelAgainstAnlb(parcel);
    renderResults(results);
    searchStatus.textContent = "";
    // Fit only after the panel has its final content and height.
    view.renderParcel(parcel, options);
  }

  function searchAndCheckParcel() {
    const query = addressInput.value.trim();
    return runSelection("Adres zoeken…", async () => {
      if (query.length < 3) {
        searchStatus.textContent = "Vul een adres of postcode in.";
        return;
      }
      const found = await pdok.findAddress(query);
      if (!found) {
        searchStatus.textContent = "Geen bruikbaar adres in Drenthe gevonden. Voeg eventueel huisnummer en plaats toe.";
        return;
      }
      const { doc, point } = found;
      const name = doc.weergavenaam ||
        [doc.straatnaam, doc.huisnummer, doc.woonplaatsnaam].filter(Boolean).join(" ") || query;
      showLocation(name, [doc.postcode, doc.woonplaatsnaam, doc.gemeentenaam]);
      view.placeAddressMarker(point);
      searchStatus.textContent = "Kadastraal perceel opzoeken via PDOK/Kadaster…";
      const parcel = await pdok.findParcelAtPoint(point);
      completeParcel(parcel, { maxZoom: 12.5 },
        "Adres gevonden, maar bij dit punt kon geen kadastraal perceel worden gevonden.");
    });
  }

  function selectPointOnMap(point) {
    return runSelection("Locatie en kadastraal perceel opzoeken…", async () => {
      view.placeAddressMarker(point);
      map.easeTo({
        center: [point.lng, point.lat],
        zoom: Math.max(map.getZoom(), 12.5),
        duration: 650
      });
      const [doc, parcel] = await Promise.all([
        pdok.reverseGeocode(point).catch(() => null),
        pdok.findParcelAtPoint(point)
      ]);
      const coordinateLabel = `${point.lat.toFixed(5)}, ${point.lng.toFixed(5)}`;
      addressInput.value = doc?.weergavenaam || coordinateLabel;
      showLocation(doc?.weergavenaam || "Gekozen locatie", doc
        ? ["Dichtstbijzijnde adres", doc.woonplaatsnaam, doc.gemeentenaam]
        : ["Gekozen kaartpositie", coordinateLabel]);
      completeParcel(parcel, { preserveView: true },
        "Bij deze kaartpositie kon geen kadastraal perceel worden gevonden.");
    });
  }

  return { searchAndCheckParcel, selectPointOnMap };
};
