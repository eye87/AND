<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Validates and normalizes uploaded ANLb GeoJSON datasets.
 */
final class AND_Kaart_Dataset_Validator {
	const MAX_UPLOAD_BYTES = 10485760;
	const MAX_FEATURES     = 10000;
	const MAX_COORDINATES  = 2000000;

	/**
	 * Validate an uploaded GeoJSON file.
	 *
	 * @param array  $file    Entry from $_FILES.
	 * @param string $dataset Either agrarisch, water or climate.
	 * @return array|WP_Error Normalized FeatureCollection or error.
	 */
	public function validate_upload( $file, $dataset ) {
		if ( ! in_array( $dataset, array( 'agrarisch', 'water', 'climate' ), true ) ) {
			return new WP_Error( 'dataset-invalid', 'Onbekend datasettype.' );
		}
		if ( ! is_array( $file ) || ! isset( $file['tmp_name'], $file['name'], $file['size'], $file['error'] ) ) {
			return new WP_Error( 'upload-missing', 'Het uploadbestand ontbreekt.' );
		}
		if ( UPLOAD_ERR_OK !== (int) $file['error'] || ! is_uploaded_file( $file['tmp_name'] ) ) {
			return new WP_Error( 'upload-failed', 'WordPress heeft geen complete upload ontvangen.' );
		}
		if ( 'geojson' !== strtolower( pathinfo( sanitize_file_name( $file['name'] ), PATHINFO_EXTENSION ) ) ) {
			return new WP_Error( 'extension-invalid', 'Alleen bestanden met de extensie .geojson zijn toegestaan.' );
		}

		$max_size = (int) apply_filters( 'and_kaart_max_upload_bytes', self::MAX_UPLOAD_BYTES );
		if ( (int) $file['size'] < 2 || (int) $file['size'] > $max_size ) {
			return new WP_Error( 'size-invalid', 'Het bestand is leeg of groter dan de toegestane 10 MB.' );
		}
		if ( ! $this->valid_mime_type( $file['tmp_name'] ) ) {
			return new WP_Error( 'mime-invalid', 'Het bestand is niet herkend als JSON of GeoJSON.' );
		}

		$raw = file_get_contents( $file['tmp_name'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		if ( false === $raw ) {
			return new WP_Error( 'read-failed', 'Het uploadbestand kon niet worden gelezen.' );
		}
		$data = json_decode( $raw, true, 128 );
		unset( $raw );
		if ( JSON_ERROR_NONE !== json_last_error() ) {
			return new WP_Error( 'json-invalid', 'Ongeldige JSON: ' . json_last_error_msg() );
		}
		if ( ! is_array( $data ) || 'FeatureCollection' !== ( $data['type'] ?? '' ) || ! is_array( $data['features'] ?? null ) ) {
			return new WP_Error( 'collection-invalid', 'Het bestand moet één GeoJSON FeatureCollection bevatten.' );
		}
		if ( ! $data['features'] || count( $data['features'] ) > self::MAX_FEATURES ) {
			return new WP_Error( 'feature-count-invalid', 'De dataset is leeg of bevat meer dan 10.000 geometrieën.' );
		}

		$coordinate_count = 0;
		$clean_features   = array();
		foreach ( $data['features'] as $index => $feature ) {
			$clean = $this->validate_feature( $feature, $dataset, $coordinate_count, $index + 1 );
			if ( is_wp_error( $clean ) ) {
				return $clean;
			}
			if ( $coordinate_count > self::MAX_COORDINATES ) {
				return new WP_Error( 'coordinate-count-invalid', 'De dataset bevat meer dan 2 miljoen coördinaten.' );
			}
			$clean_features[] = $clean;
		}

		return array(
			'type'     => 'FeatureCollection',
			'features' => $clean_features,
		);
	}

	private function valid_mime_type( $path ) {
		if ( ! function_exists( 'finfo_open' ) ) {
			return true;
		}
		$finfo = finfo_open( FILEINFO_MIME_TYPE );
		$mime  = $finfo ? finfo_file( $finfo, $path ) : '';
		if ( $finfo ) {
			finfo_close( $finfo );
		}
		return ! $mime || in_array( $mime, array( 'application/json', 'application/geo+json', 'text/plain', 'application/octet-stream' ), true );
	}

	private function validate_feature( $feature, $dataset, &$coordinate_count, $feature_number ) {
		if ( ! is_array( $feature ) || 'Feature' !== ( $feature['type'] ?? '' ) || ! is_array( $feature['geometry'] ?? null ) ) {
			return $this->feature_error( $feature_number, 'is geen geldige GeoJSON Feature.' );
		}

		$geometry = $feature['geometry'];
		$type     = $geometry['type'] ?? '';
		if ( ! in_array( $type, array( 'Polygon', 'MultiPolygon' ), true ) || ! is_array( $geometry['coordinates'] ?? null ) ) {
			return $this->feature_error( $feature_number, 'moet een Polygon of MultiPolygon zijn.' );
		}
		$polygons = 'Polygon' === $type ? array( $geometry['coordinates'] ) : $geometry['coordinates'];
		if ( ! $polygons ) {
			return $this->feature_error( $feature_number, 'bevat geen polygonen.' );
		}

		$clean_polygons = array();
		foreach ( $polygons as $polygon ) {
			if ( ! is_array( $polygon ) || ! $polygon ) {
				return $this->feature_error( $feature_number, 'bevat een lege polygoon.' );
			}
			$clean_polygon = array();
			foreach ( $polygon as $ring ) {
				if ( ! is_array( $ring ) || count( $ring ) < 4 ) {
					return $this->feature_error( $feature_number, 'bevat een ring met minder dan vier punten.' );
				}
				$clean_ring = array();
				foreach ( $ring as $coordinate ) {
					if ( ! is_array( $coordinate ) || 2 !== count( $coordinate ) || ! is_numeric( $coordinate[0] ) || ! is_numeric( $coordinate[1] ) ) {
						return $this->feature_error( $feature_number, 'bevat een ongeldige coördinaat.' );
					}
					$lon = (float) $coordinate[0];
					$lat = (float) $coordinate[1];
					if ( ! is_finite( $lon ) || ! is_finite( $lat ) || $lon < 5.5 || $lon > 7.6 || $lat < 52.2 || $lat > 53.5 ) {
						return $this->feature_error( $feature_number, 'bevat coördinaten buiten het toegestane WGS84-bereik rond Drenthe.' );
					}
					$clean_ring[] = array( round( $lon, 6 ), round( $lat, 6 ) );
					++$coordinate_count;
				}
				if ( reset( $clean_ring ) !== end( $clean_ring ) ) {
					return $this->feature_error( $feature_number, 'bevat een ring die niet gesloten is.' );
				}
				$clean_polygon[] = $clean_ring;
			}
			$clean_polygons[] = $clean_polygon;
		}

		$properties = is_array( $feature['properties'] ?? null ) ? $feature['properties'] : array();
		if ( 'agrarisch' === $dataset ) {
			$code = strtoupper( sanitize_text_field( $properties['agrarischNatuurType'] ?? '' ) );
			if ( ! preg_match( '/^A(?:11|12|15)(?:\.[0-9]+)?$/D', $code ) ) {
				return $this->feature_error( $feature_number, 'heeft geen geldige agrarische categoriecode A11, A12 of A15.' );
			}
			$clean_properties = array( 'agrarischNatuurType' => $code );
		} else {
			$code = strtoupper( sanitize_text_field( $properties['waterClimateType'] ?? '' ) );
			$required_code = 'water' === $dataset ? 'W01' : 'K01';
			if ( ! preg_match( '/^' . $required_code . '(?:\.[0-9]+)?$/D', $code ) ) {
				return $this->feature_error( $feature_number, sprintf( 'heeft geen geldige %s-code.', $required_code ) );
			}
			$clean_properties = array( 'waterClimateType' => $code );
		}

		return array(
			'type'       => 'Feature',
			'geometry'   => array(
				'type'        => $type,
				'coordinates' => 'Polygon' === $type ? $clean_polygons[0] : $clean_polygons,
			),
			'properties' => $clean_properties,
		);
	}

	private function feature_error( $number, $message ) {
		return new WP_Error( 'feature-invalid', sprintf( 'Geometrie %d %s', $number, $message ) );
	}
}
