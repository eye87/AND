<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AND_Kaart_Plugin {
	const OPTION_SETTINGS = 'and_kaart_settings';
	const OPTION_VERSIONS = 'and_kaart_versions';
	const OPTION_ACTIVE   = 'and_kaart_active_version';
	const OPTION_AUDIT    = 'and_kaart_audit_log';
	private static $instance;
	private $rendered = 0;
	private $validator;
	private $versions;

	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		require_once AND_KAART_DIR . 'includes/class-and-kaart-dataset-validator.php';
		require_once AND_KAART_DIR . 'includes/class-and-kaart-version-repository.php';
		require_once AND_KAART_DIR . 'includes/class-and-kaart-tile-settings.php';
		$this->validator = new AND_Kaart_Dataset_Validator();
		$this->versions  = new AND_Kaart_Version_Repository( self::OPTION_VERSIONS, self::OPTION_ACTIVE );
		add_action( 'admin_menu', array( $this, 'admin_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_assets' ) );
		add_action( 'admin_post_and_kaart_save_settings', array( $this, 'save_settings' ) );
		add_action( 'admin_post_and_kaart_upload_version', array( $this, 'upload_version' ) );
		add_action( 'admin_post_and_kaart_activate_version', array( $this, 'activate_version' ) );

		add_shortcode( 'perceelscheck', array( $this, 'shortcode_all' ) );
		add_shortcode( 'perceelscheck_open_grasland', array( $this, 'shortcode_grasland' ) );
		add_shortcode( 'perceelscheck_open_akkerland', array( $this, 'shortcode_akkerland' ) );
		add_shortcode( 'perceelscheck_dooradering', array( $this, 'shortcode_dooradering' ) );
		add_shortcode( 'perceelscheck_water_klimaat', array( $this, 'shortcode_water' ) );
	}

	public static function activate() {
		if ( false === get_option( self::OPTION_SETTINGS, false ) ) {
			add_option( self::OPTION_SETTINGS, self::default_settings() );
		}
		if ( false === get_option( self::OPTION_VERSIONS, false ) ) {
			add_option(
				self::OPTION_VERSIONS,
				array(
					'2026-bundled' => array(
						'label'      => 'Natuurbeheerplan Drenthe 2026',
						'agrarisch'  => 'bundled:data/agrarisch_2026.js',
						'water'      => 'bundled:data/water_klimaat_2026.js',
						'created_at' => current_time( 'mysql' ),
						'bundled'    => true,
					),
				)
			);
		}
		if ( false === get_option( self::OPTION_ACTIVE, false ) ) {
			add_option( self::OPTION_ACTIVE, '2026-bundled' );
		}
	}

	private static function default_settings() {
		return array(
			'grasland_url'     => 'https://www.agrarischenatuurdrenthe.nl/voor-deelnemers/open-grasland/',
			'akkerland_url'    => 'https://www.agrarischenatuurdrenthe.nl/voor-deelnemers/open-akkerland/',
			'dooradering_url'  => 'https://www.agrarischenatuurdrenthe.nl/voor-deelnemers/dooradering/',
			'water_url'        => 'https://www.agrarischenatuurdrenthe.nl/voor-deelnemers/water-en-klimaat/',
		) + AND_Kaart_Tile_Settings::defaults();
	}

	public function admin_menu() {
		add_menu_page(
			'Kaart',
			'Kaart',
			'manage_options',
			'and-kaart',
			array( $this, 'admin_page' ),
			'dashicons-location-alt',
			25
		);
	}

	public function admin_assets( $hook_suffix ) {
		if ( 'toplevel_page_and-kaart' !== $hook_suffix ) {
			return;
		}
		wp_enqueue_style( 'and-kaart-admin', AND_KAART_URL . 'assets/admin.css', array(), AND_KAART_VERSION );
	}

	public function admin_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$settings = wp_parse_args( get_option( self::OPTION_SETTINGS, array() ), self::default_settings() );
		$versions = $this->versions->all();
		$active   = $this->versions->active_key();
		$notice   = isset( $_GET['and_notice'] ) ? sanitize_key( wp_unslash( $_GET['and_notice'] ) ) : '';
		?>
		<div class="wrap and-kaart-admin">
			<h1>Kaart</h1>
			<?php $this->render_notice( $notice ); ?>

			<div class="and-kaart-grid">
				<section class="and-kaart-card">
					<h2>Links naar beheerpakketten</h2>
					<p>Deze links worden getoond bij een positief resultaat van de perceelscheck.</p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="and_kaart_save_settings">
						<input type="hidden" name="setting_group" value="links">
						<?php wp_nonce_field( 'and_kaart_save_settings' ); ?>
						<?php
						$fields = array(
							'grasland_url'    => 'Open grasland',
							'akkerland_url'   => 'Open akkerland',
							'dooradering_url' => 'Dooradering',
							'water_url'       => 'Water en klimaat',
						);
						foreach ( $fields as $key => $label ) :
							?>
							<label class="and-kaart-field">
								<span><?php echo esc_html( $label ); ?></span>
								<input class="regular-text" type="url" name="<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( $settings[ $key ] ); ?>">
							</label>
						<?php endforeach; ?>
						<?php submit_button( 'Links opslaan' ); ?>
					</form>
				</section>

				<section class="and-kaart-card">
					<h2>Achtergrondkaart</h2>
					<p>Gebruik HTTPS-rastertegels in XYZ-formaat, met <code>{z}</code>, <code>{x}</code> en <code>{y}</code>. Vectorstijlen en WMS-adressen worden hier niet ondersteund.</p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="and_kaart_save_settings">
						<input type="hidden" name="setting_group" value="tiles">
						<?php wp_nonce_field( 'and_kaart_save_settings' ); ?>
						<label class="and-kaart-field">
							<span>Tegeladres</span>
							<input class="large-text code" type="text" name="tile_url" value="<?php echo esc_attr( $settings['tile_url'] ); ?>" required>
						</label>
						<label class="and-kaart-field">
							<span>Bronvermelding</span>
							<input class="large-text" type="text" name="tile_attribution" value="<?php echo esc_attr( $settings['tile_attribution'] ); ?>" required>
							<small>Een link mag worden opgegeven als &lt;a href="https://..."&gt;Bronnaam&lt;/a&gt;.</small>
						</label>
						<label class="and-kaart-field">
							<span>Tegelgrootte volgens de aanbieder</span>
							<select name="tile_size">
								<option value="256" <?php selected( $settings['tile_size'], 256 ); ?>>256 pixels (OpenStreetMap)</option>
								<option value="512" <?php selected( $settings['tile_size'], 512 ); ?>>512 pixels</option>
							</select>
						</label>
						<label class="and-kaart-field">
							<span>Publieke toegangscode <small>(optioneel)</small></span>
							<input class="large-text code" type="text" name="tile_token" value="<?php echo esc_attr( $settings['tile_token'] ); ?>" autocomplete="off">
							<small>Deze code is zichtbaar voor bezoekers. Gebruik een publieke browser-token met domeinbeperking bij de aanbieder. Plaats <code>{token}</code> in het tegeladres.</small>
						</label>
						<?php submit_button( 'Achtergrondkaart opslaan' ); ?>
						<button class="button" type="submit" name="reset_tiles" value="1" formnovalidate>OpenStreetMap herstellen</button>
					</form>
				</section>

				<section class="and-kaart-card">
					<h2>Nieuwe kaartversie uploaden</h2>
					<p>Upload de drie officiële, voor webgebruik voorbereide GeoJSON-bestanden in WGS84 (EPSG:4326). De actieve versie blijft beschikbaar totdat je de complete nieuwe versie zelf activeert.</p>
					<form method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="and_kaart_upload_version">
						<?php wp_nonce_field( 'and_kaart_upload_version' ); ?>
						<label class="and-kaart-field">
							<span>Naam of jaargang</span>
							<input class="regular-text" type="text" name="version_label" placeholder="Bijv. Natuurbeheerplan Drenthe 2027" required>
						</label>
						<label class="and-kaart-field">
							<span>Agrarisch zoekgebied (.geojson)</span>
							<input type="file" name="agrarisch_file" accept=".geojson,application/geo+json,application/json" required>
						</label>
						<label class="and-kaart-field">
							<span>Waterkaart (.geojson)</span>
							<input type="file" name="water_file" accept=".geojson,application/geo+json,application/json" required>
						</label>
						<label class="and-kaart-field">
							<span>Klimaatkaart (.geojson)</span>
							<input type="file" name="climate_file" accept=".geojson,application/geo+json,application/json" required>
						</label>
						<?php submit_button( 'Versie uploaden', 'secondary' ); ?>
					</form>
				</section>
			</div>

			<section class="and-kaart-card and-kaart-versions">
				<h2>Kaartversies</h2>
				<p>Selecteer hier een eerdere versie als een nieuwe kaart fouten bevat.</p>
				<table class="widefat striped">
					<thead><tr><th>Versie</th><th>Geometrieën</th><th>Toegevoegd</th><th>Status</th><th>Actie</th></tr></thead>
					<tbody>
					<?php foreach ( array_reverse( $versions, true ) as $slug => $version ) : ?>
						<tr>
							<td><strong><?php echo esc_html( $version['label'] ); ?></strong><?php if ( empty( $version['climate'] ) ) : ?><br><small>Gecombineerde oudere versie</small><?php endif; ?></td>
							<td><?php
							echo esc_html( isset( $version['agrarisch_count'] ) ? 'Agrarisch: ' . $version['agrarisch_count'] : 'Ingebouwde set' );
							if ( isset( $version['water_count'] ) ) {
								echo '<br>' . esc_html( ( empty( $version['climate'] ) ? 'Water + Klimaat: ' : 'Water: ' ) . $version['water_count'] );
							}
							if ( isset( $version['climate_count'] ) ) {
								echo '<br>' . esc_html( 'Klimaat: ' . $version['climate_count'] );
							}
							?></td>
							<td><?php echo esc_html( $version['created_at'] ); ?></td>
							<td><?php echo $slug === $active ? '<span class="and-active">Actief</span>' : 'Beschikbaar'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
							<td>
							<?php if ( $slug !== $active ) : ?>
								<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
									<input type="hidden" name="action" value="and_kaart_activate_version">
									<input type="hidden" name="version" value="<?php echo esc_attr( $slug ); ?>">
									<?php wp_nonce_field( 'and_kaart_activate_version_' . $slug ); ?>
									<button class="button" type="submit">Deze versie activeren</button>
								</form>
							<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</section>

			<section class="and-kaart-card">
				<h2>Shortcodes</h2>
				<p>Plaats per pagina één van deze shortcodes. Alleen de beginselectie verschilt; bezoekers kunnen altijd andere lagen aan- of uitzetten.</p>
				<table class="widefat striped"><tbody>
					<tr><td>Alle lagen actief</td><td><code>[perceelscheck]</code></td></tr>
					<tr><td>Alleen Open grasland</td><td><code>[perceelscheck_open_grasland]</code></td></tr>
					<tr><td>Alleen Open akkerland</td><td><code>[perceelscheck_open_akkerland]</code></td></tr>
					<tr><td>Alleen Dooradering</td><td><code>[perceelscheck_dooradering]</code></td></tr>
					<tr><td>Alleen Water en klimaat</td><td><code>[perceelscheck_water_klimaat]</code></td></tr>
				</tbody></table>
			</section>

			<section class="and-kaart-card">
				<h2>Recente beheeracties</h2>
				<p>De laatste uploads, activeringen en instellingenwijzigingen worden lokaal vastgelegd.</p>
				<table class="widefat striped"><thead><tr><th>Tijd</th><th>Gebruiker</th><th>Actie</th></tr></thead><tbody>
				<?php foreach ( array_reverse( array_slice( get_option( self::OPTION_AUDIT, array() ), -10 ) ) as $entry ) : ?>
					<tr><td><?php echo esc_html( $entry['time'] ?? '' ); ?></td><td><?php echo esc_html( get_the_author_meta( 'display_name', (int) ( $entry['user_id'] ?? 0 ) ) ); ?></td><td><?php echo esc_html( $entry['action'] ?? '' ); ?></td></tr>
				<?php endforeach; ?>
				</tbody></table>
			</section>
		</div>
		<?php
	}

	private function render_notice( $notice ) {
		$messages = array(
			'settings-saved'  => array( 'success', 'De instellingen zijn opgeslagen.' ),
			'version-uploaded'=> array( 'success', 'De kaartversie is geüpload en staat klaar om te activeren.' ),
			'version-active'  => array( 'success', 'De geselecteerde kaartversie is nu actief.' ),
			'insecure-url'    => array( 'error', 'Links en tegeladressen moeten met https:// beginnen.' ),
			'tile-url-invalid'=> array( 'error', 'Het tegeladres moet geldig zijn en {z}, {x} en {y} bevatten.' ),
			'tile-token-invalid' => array( 'error', 'De publieke toegangscode bevat ongeldige tekens of is te lang.' ),
		);
		if ( 'settings-error' === $notice ) {
			$messages[ $notice ] = array( 'error', $this->consume_admin_error( 'De instellingen zijn niet opgeslagen.' ) );
		} elseif ( 'upload-error' === $notice ) {
			$messages[ $notice ] = array( 'error', $this->consume_admin_error( 'De upload is niet gelukt.' ) );
		} elseif ( 'version-error' === $notice ) {
			$messages[ $notice ] = array( 'error', $this->consume_admin_error( 'De kaartversie kon niet worden geactiveerd.' ) );
		}
		if ( isset( $messages[ $notice ] ) ) {
			printf( '<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>', esc_attr( $messages[ $notice ][0] ), esc_html( $messages[ $notice ][1] ) );
		}
	}

	public function save_settings() {
		$this->guard_admin_action( 'and_kaart_save_settings' );
		$defaults = self::default_settings();
		$settings = wp_parse_args( get_option( self::OPTION_SETTINGS, array() ), $defaults );
		$group    = isset( $_POST['setting_group'] ) ? sanitize_key( wp_unslash( $_POST['setting_group'] ) ) : 'links';
		if ( 'links' === $group ) {
			foreach ( array( 'grasland_url', 'akkerland_url', 'dooradering_url', 'water_url' ) as $key ) {
				$value = isset( $_POST[ $key ] ) ? trim( wp_unslash( $_POST[ $key ] ) ) : '';
				if ( $value && 0 !== stripos( $value, 'https://' ) ) {
					$this->redirect_admin( 'insecure-url' );
				}
				$settings[ $key ] = esc_url_raw( $value, array( 'https' ) );
			}
		} elseif ( 'tiles' === $group ) {
			$tiles = isset( $_POST['reset_tiles'] )
				? AND_Kaart_Tile_Settings::defaults()
				: AND_Kaart_Tile_Settings::validate( wp_unslash( $_POST ) );
			if ( is_wp_error( $tiles ) ) {
				$this->redirect_with_error( 'settings-error', $tiles );
			}
			$settings = array_merge( $settings, $tiles );
		} else {
			$this->redirect_admin( 'tile-url-invalid' );
		}
		update_option( self::OPTION_SETTINGS, $settings );
		$this->audit( 'settings_updated' );
		$this->redirect_admin( 'settings-saved' );
	}

	public function upload_version() {
		$this->guard_admin_action( 'and_kaart_upload_version' );
		$label = isset( $_POST['version_label'] ) ? sanitize_text_field( wp_unslash( $_POST['version_label'] ) ) : '';
		if ( ! $label || empty( $_FILES['agrarisch_file']['tmp_name'] ) || empty( $_FILES['water_file']['tmp_name'] ) || empty( $_FILES['climate_file']['tmp_name'] ) ) {
			$this->redirect_with_error( 'upload-error', new WP_Error( 'upload-missing', 'Vul een versienaam in en selecteer alle drie de GeoJSON-bestanden.' ) );
		}

		$agrarisch = $this->validator->validate_upload( $_FILES['agrarisch_file'], 'agrarisch' );
		if ( is_wp_error( $agrarisch ) ) {
			$this->redirect_with_error( 'upload-error', $agrarisch );
		}
		$water = $this->validator->validate_upload( $_FILES['water_file'], 'water' );
		if ( is_wp_error( $water ) ) {
			$this->redirect_with_error( 'upload-error', $water );
		}
		$climate = $this->validator->validate_upload( $_FILES['climate_file'], 'climate' );
		if ( is_wp_error( $climate ) ) {
			$this->redirect_with_error( 'upload-error', $climate );
		}
		$stored = $this->versions->store( $label, $agrarisch, $water, $climate );
		if ( is_wp_error( $stored ) ) {
			$this->redirect_with_error( 'upload-error', $stored );
		}
		$this->audit( 'version_uploaded', array( 'version' => $stored['slug'], 'label' => $label ) );
		$this->redirect_admin( 'version-uploaded' );
	}

	private function audit( $action, $context = array() ) {
		$log   = get_option( self::OPTION_AUDIT, array() );
		$log[] = array( 'time' => current_time( 'mysql' ), 'user_id' => get_current_user_id(), 'action' => $action, 'context' => $context );
		update_option( self::OPTION_AUDIT, array_slice( $log, -100 ), false );
	}

	public function activate_version() {
		$slug = isset( $_POST['version'] ) ? sanitize_key( wp_unslash( $_POST['version'] ) ) : '';
		$this->guard_admin_action( 'and_kaart_activate_version_' . $slug );
		$result = $this->versions->activate( $slug );
		if ( is_wp_error( $result ) ) {
			$this->redirect_with_error( 'version-error', $result );
		}
		$this->audit( 'version_activated', array( 'version' => $slug ) );
		$this->redirect_admin( 'version-active' );
	}

	private function guard_admin_action( $nonce_action ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Je hebt onvoldoende rechten voor deze actie.', 'and-perceelscheck' ) );
		}
		check_admin_referer( $nonce_action );
	}

	private function redirect_admin( $notice ) {
		wp_safe_redirect( add_query_arg( 'and_notice', $notice, admin_url( 'admin.php?page=and-kaart' ) ) );
		exit;
	}

	private function redirect_with_error( $notice, $error ) {
		set_transient( 'and_kaart_error_' . get_current_user_id(), $error->get_error_message(), MINUTE_IN_SECONDS );
		$this->redirect_admin( $notice );
	}

	private function consume_admin_error( $fallback ) {
		$key     = 'and_kaart_error_' . get_current_user_id();
		$message = get_transient( $key );
		delete_transient( $key );
		return $message ? $message : $fallback;
	}

	public function shortcode_all() {
		return $this->render_shortcode( array( 'grasland', 'akkerland', 'dooradering', 'water' ) );
	}

	public function shortcode_grasland() {
		return $this->render_shortcode( array( 'grasland' ) );
	}

	public function shortcode_akkerland() {
		return $this->render_shortcode( array( 'akkerland' ) );
	}

	public function shortcode_dooradering() {
		return $this->render_shortcode( array( 'dooradering' ) );
	}

	public function shortcode_water() {
		return $this->render_shortcode( array( 'water' ) );
	}

	private function render_shortcode( $active_layers ) {
		$this->enqueue_frontend();
		$this->rendered++;
		$id       = 'and-perceelscheck-' . $this->rendered;
		$settings = wp_parse_args( get_option( self::OPTION_SETTINGS, array() ), self::default_settings() );
		$version  = $this->versions->active();
		if ( is_wp_error( $version ) ) {
			return '<p class="and-perceelscheck-error">De Perceelscheck is tijdelijk niet beschikbaar.</p>';
		}
		$data_urls = array(
			'agrarisch' => $this->versions->data_url( $version['agrarisch'] ),
			'water'     => $this->versions->data_url( $version['water'] ),
			'climate'   => ! empty( $version['climate'] ) ? $this->versions->data_url( $version['climate'] ) : '',
		);
		$config = array(
			'activeLayers' => array_values( $active_layers ),
			'tileSource'   => AND_Kaart_Tile_Settings::frontend( $settings ),
			'packageUrls'  => array(
				'grasland'    => $settings['grasland_url'],
				'akkerland'   => $settings['akkerland_url'],
				'dooradering' => $settings['dooradering_url'],
				'water'       => $settings['water_url'],
			),
			'dataUrls'      => $data_urls,
			'dataOrigins'   => $this->data_origins( $data_urls ),
		);

		ob_start();
		?>
		<div id="<?php echo esc_attr( $id ); ?>" class="anlb-perceelscheck" data-config="<?php echo esc_attr( wp_json_encode( $config ) ); ?>">
			<div class="anlb-map" aria-label="Kaart van Drenthe met officiële ANLb-vectorlagen"></div>
			<button type="button" class="mobile-layers-toggle" aria-label="Kaartlagen openen" aria-controls="<?php echo esc_attr( $id ); ?>-layer-list" aria-expanded="false"></button>
			<aside class="panel" aria-label="ANLb perceelcheck">
				<h1>Perceelscheck</h1>
				<div class="data-status"></div>
				<div class="search-wrap">
					<div class="address-field">
						<input class="address-input" type="search" autocomplete="off" placeholder="Bekijk je kansen per adres" aria-label="Adres of postcode" role="combobox" aria-autocomplete="list" aria-expanded="false" aria-controls="<?php echo esc_attr( $id ); ?>-address-suggestions" disabled>
						<button type="button" class="address-clear" aria-label="Adres wissen">×</button>
						<ul id="<?php echo esc_attr( $id ); ?>-address-suggestions" class="address-suggestions" role="listbox" aria-label="Adresvoorstellen" hidden></ul>
					</div>
					<button type="button" class="primary search-button" aria-label="Zoeken" disabled>Zoeken</button>
				</div>
				<div class="status search-status" aria-live="polite">Kaart wordt geladen…</div>
				<details class="parcel-card">
					<summary class="parcel-summary"><span class="location-name"></span><span class="parcel-summary-meta"></span></summary>
					<div class="parcel-details"><div class="location-meta"></div><div class="parcel-grid">
						<div><span class="parcel-label">Gemeente</span><span class="parcel-value parcel-municipality">–</span></div>
						<div><span class="parcel-label">Sectie</span><span class="parcel-value parcel-section">–</span></div>
						<div><span class="parcel-label">Perceelnummer</span><span class="parcel-value parcel-number">–</span></div>
						<div><span class="parcel-label">Kadastrale grootte</span><span class="parcel-value parcel-area">–</span></div>
					</div></div>
				</details>
				<div class="result-box" aria-live="polite"><div class="result-title">Beschikbare beheerpakketten</div><div class="result-list"></div></div>
				<h2>Kaartlagen</h2>
				<div id="<?php echo esc_attr( $id ); ?>-layer-list" class="layer-list grouped">
					<?php $this->layer_checkbox( 'grasland', 'Open grasland', $active_layers ); ?>
					<?php $this->layer_checkbox( 'akkerland', 'Open akkerland', $active_layers ); ?>
					<?php $this->layer_checkbox( 'dooradering', 'Dooradering', $active_layers ); ?>
					<?php $this->layer_checkbox( 'water', 'Water en klimaat', $active_layers ); ?>
				</div>
				<div class="note">Agrarisch Natuur Drenthe - Perceelgrenzen zijn indicatief</div>
			</aside>
		</div>
		<?php
		return ob_get_clean();
	}

	private function data_origins( $urls ) {
		$origins = array();
		foreach ( $urls as $url ) {
			if ( ! $url ) {
				continue;
			}
			$parts = wp_parse_url( $url );
			$scheme = strtolower( $parts['scheme'] ?? '' );
			$host   = strtolower( $parts['host'] ?? '' );
			if ( ! in_array( $scheme, array( 'http', 'https' ), true ) || ! $host ) {
				continue;
			}
			$origin = $scheme . '://' . $host;
			if ( ! empty( $parts['port'] ) ) {
				$origin .= ':' . (int) $parts['port'];
			}
			$origins[] = $origin;
		}
		return array_values( array_unique( $origins ) );
	}

	private function layer_checkbox( $key, $label, $active_layers ) {
		?>
		<label class="layer-row" data-layer-row="<?php echo esc_attr( $key ); ?>"><input type="checkbox" data-layer="<?php echo esc_attr( $key ); ?>" <?php checked( in_array( $key, $active_layers, true ) ); ?>><span class="legend-swatch"></span><span><?php echo esc_html( $label ); ?></span><small class="layer-load-state"></small></label>
		<?php
	}

	private function enqueue_frontend() {
		wp_enqueue_style( 'and-maplibre', AND_KAART_URL . 'vendor/maplibre/maplibre-gl.css', array(), '5.6.0' );
		wp_enqueue_style( 'and-perceelscheck', AND_KAART_URL . 'assets/perceelscheck.css', array( 'and-maplibre' ), AND_KAART_VERSION );
		wp_enqueue_script( 'and-maplibre', AND_KAART_URL . 'vendor/maplibre/maplibre-gl.js', array(), '5.6.0', true );
		wp_enqueue_script( 'and-turf', AND_KAART_URL . 'vendor/turf/turf.min.js', array(), '7.2.0', true );
		wp_enqueue_script( 'and-province-data', AND_KAART_URL . 'data/provincie_drenthe.js', array(), AND_KAART_VERSION, true );
		wp_enqueue_script( 'and-geometry', AND_KAART_URL . 'assets/geometry.js', array(), AND_KAART_VERSION, true );
		$dependencies = array( 'and-maplibre', 'and-turf', 'and-province-data', 'and-geometry' );
		foreach ( array( 'datasets', 'map-view', 'pdok', 'results-view', 'selection-controller', 'address-autocomplete', 'mobile-controls' ) as $module ) {
			$handle = 'and-' . $module;
			wp_enqueue_script( $handle, AND_KAART_URL . 'assets/' . $module . '.js', array( 'and-geometry' ), AND_KAART_VERSION, true );
			$dependencies[] = $handle;
		}
		wp_enqueue_script( 'and-perceelscheck', AND_KAART_URL . 'assets/perceelscheck.js', $dependencies, AND_KAART_VERSION, true );
	}

}
