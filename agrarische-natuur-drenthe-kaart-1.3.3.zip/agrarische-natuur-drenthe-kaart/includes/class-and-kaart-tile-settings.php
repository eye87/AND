<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Settings for HTTPS XYZ raster tiles; no server-side requests to providers. */
final class AND_Kaart_Tile_Settings {
	public static function defaults() {
		return array(
			'tile_url' => 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
			'tile_attribution' => '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap-bijdragers</a>',
			'tile_token' => '',
			'tile_size' => 256,
		);
	}

	public static function validate( $input ) {
		foreach ( array( 'tile_url', 'tile_attribution', 'tile_token' ) as $key ) {
			if ( ! isset( $input[ $key ] ) || ! is_string( $input[ $key ] ) ) {
				return new WP_Error( 'tile-invalid', 'Vul een geldig tegeladres en een bronvermelding in.' );
			}
		}
		$url = trim( $input['tile_url'] );
		$token = trim( $input['tile_token'] );
		$size = $input['tile_size'] ?? 256;
		if ( ! in_array( $size, array( 256, 512, '256', '512' ), true ) ) {
			return new WP_Error( 'tile-invalid', 'Kies een tegelgrootte van 256 of 512 pixels.' );
		}
		foreach ( array( '{z}', '{x}', '{y}' ) as $placeholder ) {
			if ( false === strpos( $url, $placeholder ) ) {
				return new WP_Error( 'tile-invalid', 'Het tegeladres moet {z}, {x} en {y} bevatten.' );
			}
		}
		$test = str_replace( array( '{z}', '{x}', '{y}', '{token}' ), array( '8', '128', '128', 'token' ), $url );
		$parts = wp_parse_url( $test );
		if ( strlen( $url ) > 2048 || ! filter_var( $test, FILTER_VALIDATE_URL ) ||
			'https' !== ( $parts['scheme'] ?? '' ) || empty( $parts['host'] ) ||
			isset( $parts['user'] ) || isset( $parts['pass'] ) || isset( $parts['fragment'] ) ||
			strpbrk( $test, "{}<>\\\"' " ) !== false ||
			false !== strpos( $url, 'https://{token}' ) ||
			false !== strpos( (string) ( wp_parse_url( $url, PHP_URL_HOST ) ), '{' ) ) {
			return new WP_Error( 'tile-invalid', 'Gebruik een volledig HTTPS-tegeladres zonder inloggegevens, fragmenten of onbekende placeholders.' );
		}
		if ( strlen( $token ) > 512 || ( $token && ! preg_match( '/^[A-Za-z0-9._~+\/=\-]+$/D', $token ) ) ||
			( false !== strpos( $url, '{token}' ) && ! $token ) ) {
			return new WP_Error( 'tile-invalid', 'Vul bij {token} een geldige publieke browser-token in.' );
		}
		// Only hyperlinks are allowed; scripts, styling and event attributes are removed.
		$attribution = wp_kses( $input['tile_attribution'], array( 'a' => array( 'href' => true, 'title' => true ) ), array( 'https' ) );
		if ( strlen( $attribution ) > 2048 || '' === trim( wp_strip_all_tags( $attribution ) ) ) {
			return new WP_Error( 'tile-invalid', 'Vul een bronvermelding in (maximaal 2048 tekens).' );
		}
		return array( 'tile_url' => $url, 'tile_attribution' => $attribution, 'tile_token' => $token, 'tile_size' => (int) $size );
	}

	public static function frontend( $settings ) {
		$tiles = self::validate( $settings );
		if ( is_wp_error( $tiles ) ) {
			$tiles = self::defaults();
		}
		return array(
			'url' => str_replace( '{token}', rawurlencode( $tiles['tile_token'] ), $tiles['tile_url'] ),
			'attribution' => $tiles['tile_attribution'],
			'tileSize' => $tiles['tile_size'],
		);
	}
}
