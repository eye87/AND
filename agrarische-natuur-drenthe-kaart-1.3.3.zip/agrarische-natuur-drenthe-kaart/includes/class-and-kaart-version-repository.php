<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Stores complete map versions and exposes their public data URLs.
 */
final class AND_Kaart_Version_Repository {
	private const BUNDLED_JS_HASHES = array(
		'agrarisch' => 'feef0d2f23b09c3c73d511f86b310a6c53d16cb64e38a641037f14369fb89462',
		'water'     => '62be4bbcc3a527095fab29917da40a4f15ad909d276d87fa853b1aeb329ef6fb',
	);

	private $option_versions;
	private $option_active;
	private $verified_fingerprints = array();

	public function __construct( $option_versions, $option_active ) {
		$this->option_versions = $option_versions;
		$this->option_active   = $option_active;
	}

	public function all() {
		return get_option( $this->option_versions, array() );
	}

	public function active_key() {
		return get_option( $this->option_active, '2026-bundled' );
	}

	public function active() {
		$versions = $this->all();
		$active   = $this->active_key();
		if ( isset( $versions[ $active ] ) ) {
			return $this->version_files_exist( $versions[ $active ], false, $active )
				? $versions[ $active ]
				: new WP_Error( 'version-files-missing', 'De actieve kaartversie is onvolledig of gewijzigd.' );
		}
		return new WP_Error( 'version-missing', 'De actieve kaartversie bestaat niet. Selecteer een complete kaartversie in het beheer.' );
	}

	public function activate( $slug ) {
		$versions = $this->all();
		if ( ! isset( $versions[ $slug ] ) ) {
			return new WP_Error( 'version-missing', 'De geselecteerde kaartversie bestaat niet.' );
		}
		if ( ! $this->version_files_exist( $versions[ $slug ], true, $slug ) ) {
			return new WP_Error( 'version-files-missing', 'Een of meer bestanden van deze kaartversie ontbreken.' );
		}
		update_option( $this->option_active, $slug );
		return true;
	}

	public function store( $label, $agrarisch, $water, $climate ) {
		$upload = wp_upload_dir();
		if ( ! empty( $upload['error'] ) ) {
			return new WP_Error( 'upload-directory', $upload['error'] );
		}

		$slug      = sanitize_title( $label ) . '-' . gmdate( 'Ymd-His' ) . '-' . strtolower( wp_generate_password( 6, false, false ) );
		$base_dir  = trailingslashit( $upload['basedir'] ) . 'and-perceelscheck';
		$temp_dir  = trailingslashit( $base_dir ) . '.tmp-' . wp_generate_password( 12, false, false );
		$final_dir = trailingslashit( $base_dir ) . $slug;
		if ( ! wp_mkdir_p( $temp_dir ) ) {
			return new WP_Error( 'directory-create', 'De tijdelijke kaartmap kon niet worden gemaakt.' );
		}

		$json_flags      = JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT;
		$agrarisch_json = wp_json_encode( $agrarisch, $json_flags );
		$water_json     = wp_json_encode( $water, $json_flags );
		$climate_json   = wp_json_encode( $climate, $json_flags );
		if ( false === $agrarisch_json || false === $water_json || false === $climate_json ) {
			$this->remove_directory( $temp_dir );
			return new WP_Error( 'json-encode', 'De gevalideerde kaartdata kon niet worden opgeslagen.' );
		}

		$agrarisch_js = 'window.ANLB_AGRARISCH_DATA=' . $agrarisch_json . ';';
		$water_js     = 'window.ANLB_WATER_DATA=' . $water_json . ';';
		$climate_js   = 'window.ANLB_KLIMAAT_DATA=' . $climate_json . ';';
		$files = array(
			'agrarisch.geojson' => $agrarisch_json,
			'agrarisch.js'      => $agrarisch_js,
			'water.geojson'     => $water_json,
			'water.js'          => $water_js,
			'climate.geojson'   => $climate_json,
			'climate.js'        => $climate_js,
			'index.php'         => "<?php\n// Silence is golden.\n",
			'.htaccess'         => "Options -Indexes\n<FilesMatch \"\\.(php|phtml|phar)$\">\nRequire all denied\n</FilesMatch>\n",
		);
		foreach ( $files as $name => $contents ) {
			if ( false === file_put_contents( trailingslashit( $temp_dir ) . $name, $contents, LOCK_EX ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
				$this->remove_directory( $temp_dir );
				return new WP_Error( 'file-write', sprintf( 'Het bestand %s kon niet worden geschreven.', $name ) );
			}
		}

		if (
			file_get_contents( trailingslashit( $temp_dir ) . 'agrarisch.geojson' ) !== $agrarisch_json ||
			file_get_contents( trailingslashit( $temp_dir ) . 'agrarisch.js' ) !== $agrarisch_js ||
			file_get_contents( trailingslashit( $temp_dir ) . 'water.geojson' ) !== $water_json ||
			file_get_contents( trailingslashit( $temp_dir ) . 'water.js' ) !== $water_js ||
			file_get_contents( trailingslashit( $temp_dir ) . 'climate.geojson' ) !== $climate_json ||
			file_get_contents( trailingslashit( $temp_dir ) . 'climate.js' ) !== $climate_js
		) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			$this->remove_directory( $temp_dir );
			return new WP_Error( 'file-verify', 'De geschreven kaartbestanden konden niet worden geverifieerd.' );
		}
		if ( ! rename( $temp_dir, $final_dir ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename
			$this->remove_directory( $temp_dir );
			return new WP_Error( 'directory-finalize', 'De kaartversie kon niet definitief worden gemaakt.' );
		}

		$relative = 'uploads:and-perceelscheck/' . $slug . '/';
		$version  = array(
			'format'            => 'separate-v1',
			'label'             => $label,
			'agrarisch'         => $relative . 'agrarisch.js',
			'water'             => $relative . 'water.js',
			'climate'           => $relative . 'climate.js',
			'agrarisch_count'   => count( $agrarisch['features'] ),
			'water_count'       => count( $water['features'] ),
			'climate_count'     => count( $climate['features'] ),
			'agrarisch_sha256'  => hash( 'sha256', $agrarisch_json ),
			'water_sha256'      => hash( 'sha256', $water_json ),
			'climate_sha256'    => hash( 'sha256', $climate_json ),
			'agrarisch_js_sha256' => hash( 'sha256', $agrarisch_js ),
			'water_js_sha256'     => hash( 'sha256', $water_js ),
			'climate_js_sha256'   => hash( 'sha256', $climate_js ),
			'created_at'        => current_time( 'mysql' ),
			'created_by'        => get_current_user_id(),
			'bundled'           => false,
		);
		$versions          = $this->all();
		$versions[ $slug ] = $version;
		if ( ! update_option( $this->option_versions, $versions, false ) ) {
			$this->remove_directory( $final_dir );
			return new WP_Error( 'version-register', 'De kaartversie kon niet in WordPress worden geregistreerd.' );
		}
		return array( 'slug' => $slug, 'version' => $version );
	}

	public function data_url( $path ) {
		if ( 0 === strpos( $path, 'bundled:' ) ) {
			return AND_KAART_URL . substr( $path, 8 );
		}
		if ( 0 === strpos( $path, 'uploads:' ) ) {
			$upload = wp_upload_dir();
			return trailingslashit( $upload['baseurl'] ) . substr( $path, 8 );
		}
		return '';
	}

	private function version_files_exist( $version, $force = false, $cache_id = '' ) {
		$required_files = ( 'separate-v1' === ( $version['format'] ?? '' ) || array_key_exists( 'climate', $version ) )
			? array( 'agrarisch', 'water', 'climate' )
			: array( 'agrarisch', 'water' );
		$version_files = array();
		foreach ( $required_files as $key ) {
			$path = $version[ $key ] ?? '';
			$file = $this->data_path( $path );
			if ( ! $file || ! file_exists( $file ) ) {
				return false;
			}

			$geojson          = preg_replace( '/\.js$/', '.geojson', $file );
			$geojson_hash_key = $key . '_sha256';
			if ( 'separate-v1' === ( $version['format'] ?? '' ) &&
				( empty( $version[ $geojson_hash_key ] ) || empty( $version[ $key . '_js_sha256' ] ) ) ) {
				return false;
			}
			$version_files[ $key ] = array(
				'path'    => $path,
				'js'      => $file,
				'geojson' => $geojson && file_exists( $geojson ) ? $geojson : '',
			);
		}

		$fingerprint = $this->verification_fingerprint( $version, $version_files );
		if ( ! $fingerprint ) {
			return false;
		}
		$cache_key = 'and_kaart_verified_' . md5( $cache_id . '|' . wp_json_encode( $version ) );
		if ( ! $force &&
			( ( $this->verified_fingerprints[ $cache_key ] ?? '' ) === $fingerprint || get_transient( $cache_key ) === $fingerprint ) ) {
			$this->verified_fingerprints[ $cache_key ] = $fingerprint;
			return true;
		}

		foreach ( $version_files as $key => $files ) {
			$path              = $files['path'];
			$file              = $files['js'];
			$geojson           = $files['geojson'];
			$geojson_hash_key  = $key . '_sha256';
			if ( ! empty( $version[ $geojson_hash_key ] ) ) {
				$actual_geojson_hash = $geojson ? hash_file( 'sha256', $geojson ) : false;
				if ( ! is_string( $actual_geojson_hash ) || ! hash_equals( $version[ $geojson_hash_key ], $actual_geojson_hash ) ) {
					return false;
				}
			}

			$expected_js_hash = $version[ $key . '_js_sha256' ] ?? '';
			if ( ! $expected_js_hash && 0 === strpos( $path, 'bundled:' ) ) {
				$expected_js_hash = self::BUNDLED_JS_HASHES[ $key ] ?? '';
			}
			if ( ! $expected_js_hash && $geojson && file_exists( $geojson ) ) {
				$geojson_contents = file_get_contents( $geojson ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
				$global_names = array(
					'agrarisch' => 'ANLB_AGRARISCH_2026',
					'water'     => ! empty( $version['climate'] ) ? 'ANLB_WATER_2026' : 'ANLB_WATER_KLIMAAT_2026',
					'climate'   => 'ANLB_KLIMAAT_2026',
				);
				$global_name = $global_names[ $key ];
				if ( is_string( $geojson_contents ) ) {
					$expected_js_hash = hash( 'sha256', 'window.' . $global_name . '=' . $geojson_contents . ';' );
				}
			}
			$actual_js_hash = hash_file( 'sha256', $file );
			if ( ! $expected_js_hash || ! is_string( $actual_js_hash ) || ! hash_equals( $expected_js_hash, $actual_js_hash ) ) {
				return false;
			}
		}
		$this->verified_fingerprints[ $cache_key ] = $fingerprint;
		set_transient( $cache_key, $fingerprint, DAY_IN_SECONDS );
		return true;
	}

	private function verification_fingerprint( $version, $version_files ) {
		$state = array( 'version' => $version, 'files' => array() );
		foreach ( $version_files as $key => $files ) {
			foreach ( array( 'js', 'geojson' ) as $type ) {
				$file = $files[ $type ];
				if ( ! $file ) {
					continue;
				}
				clearstatcache( true, $file );
				$size  = filesize( $file );
				$mtime = filemtime( $file );
				$ctime = filectime( $file );
				if ( false === $size || false === $mtime || false === $ctime ) {
					return false;
				}
				$state['files'][ $key . ':' . $type ] = array( $size, $mtime, $ctime );
			}
		}
		$encoded = wp_json_encode( $state );
		return $encoded ? hash( 'sha256', $encoded ) : false;
	}

	private function data_path( $path ) {
		if ( 0 === strpos( $path, 'bundled:' ) ) {
			return AND_KAART_DIR . substr( $path, 8 );
		}
		if ( 0 === strpos( $path, 'uploads:' ) ) {
			$upload = wp_upload_dir();
			return trailingslashit( $upload['basedir'] ) . substr( $path, 8 );
		}
		return '';
	}

	private function remove_directory( $dir ) {
		if ( ! is_dir( $dir ) ) {
			return;
		}
		foreach ( scandir( $dir ) as $item ) { // phpcs:ignore WordPress.CodeAnalysis.AssignmentInCondition.Found
			if ( '.' !== $item && '..' !== $item && is_file( trailingslashit( $dir ) . $item ) ) {
				unlink( trailingslashit( $dir ) . $item ); // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
			}
		}
		rmdir( $dir ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_rmdir
	}
}
