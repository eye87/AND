=== Agrarische Natuur Drenthe – Perceelscheck ===
Contributors: agrarischenatuurdrenthe
Requires at least: 6.2
Requires PHP: 7.4
Stable tag: 1.3.3
License: GPLv2 or later

Interactieve Perceelscheck met progressief laden, vijf shortcodes, instelbare kaartbron en beheerpakketlinks, en terugrolbare kaartversies.

== Installatie ==

1. Upload de map `agrarische-natuur-drenthe-kaart` naar `/wp-content/plugins/`.
2. Activeer de plugin in WordPress.
3. Open `Kaart` in het hoofdmenu en controleer de links en actieve kaartversie.
4. Plaats één van de getoonde shortcodes op een pagina.

== Kaartupdates ==

Upload onder `Kaart` drie voor webgebruik voorbereide GeoJSON-bestanden in WGS84 (EPSG:4326): Agrarisch zoekgebied, Waterkaart en Klimaatkaart. Ze worden afzonderlijk gecontroleerd en samen als één complete kaartversie opgeslagen. De nieuwe versie wordt niet automatisch geactiveerd en eerdere versies blijven selecteerbaar. Oudere versies met één gecombineerd bestand voor Water en klimaat blijven ondersteund.

== Beveiliging ==

Alle beheeracties vereisen beheerdersrechten en een geldige WordPress-nonce. Uploads zijn beperkt tot `.geojson`, maximaal 10 MB, Polygon/MultiPolygon-geometrie, gesloten ringen, bekende categoriecodes en WGS84-coördinaten in en rond Drenthe. Onnodige eigenschappen worden verwijderd en externe links en tegeladressen moeten HTTPS gebruiken. Een nieuwe kaartversie kan alleen volledig worden geactiveerd. MapLibre en Turf zijn lokaal en versiegebonden opgenomen.

== Laadstrategie ==

De basiskaart en provinciecontour verschijnen eerst. Agrarisch, Water en Klimaat downloaden parallel; Water en Klimaat worden aan de voorkant als één categorie verwerkt. Zo hoeft de basiskaart niet op alle gebiedsdata te wachten.
