import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";

class FakeElement {
  constructor(id = "") {
    this.id = id;
    this.value = "";
    this.hidden = true;
    this.children = [];
    this.attributes = new Map();
    this.listeners = new Map();
    this.classes = new Set();
    this.classList = { toggle: (name, active) => active ? this.classes.add(name) : this.classes.delete(name) };
  }
  addEventListener(type, listener) { this.listeners.set(type, listener); }
  dispatch(type, properties = {}) {
    const event = { key: "", preventDefault() { this.defaultPrevented = true; }, ...properties };
    this.listeners.get(type)?.(event);
    return event;
  }
  setAttribute(name, value) { this.attributes.set(name, String(value)); }
  removeAttribute(name) { this.attributes.delete(name); }
  replaceChildren() { this.children = []; }
  appendChild(child) { this.children.push(child); }
  contains(element) { return this.children.includes(element); }
  scrollIntoView() {}
}

const source = fs.readFileSync(new URL("../assets/address-autocomplete.js", import.meta.url), "utf8");
const document = { activeElement: null, createElement: () => new FakeElement() };
const context = vm.createContext({ window: {}, document, setTimeout, clearTimeout });
vm.runInContext(source, context);

const input = new FakeElement("address");
const list = new FakeElement("suggestions");
let calls = 0;
const pdok = { suggestAddresses: async query => {
  calls += 1;
  return [{ label: `${query} 1, Assen`, type: "adres", id: "1" }];
} };
let submits = 0;
context.window.ANDPerceelscheck.createAddressAutocomplete({
  input, list, pdok, onSubmit: () => { submits += 1; }, delayMs: 0
});

input.value = "Br";
input.dispatch("input");
await new Promise(resolve => setTimeout(resolve, 5));
assert.equal(calls, 0);
assert.equal(list.hidden, true);

input.value = "Bri";
input.dispatch("input");
input.value = "Brink";
input.dispatch("input");
await new Promise(resolve => setTimeout(resolve, 5));
assert.equal(calls, 1, "debounce only requests the latest query");
assert.equal(list.hidden, false);
assert.equal(list.children.length, 1);
assert.equal(input.attributes.get("aria-expanded"), "true");

input.dispatch("keydown", { key: "ArrowDown" });
assert.equal(input.attributes.get("aria-activedescendant"), "suggestions-option-0");
input.dispatch("keydown", { key: "Enter" });
assert.equal(input.value, "Brink 1, Assen");
assert.equal(submits, 1);
assert.equal(list.hidden, true);

input.value = "Assen";
input.dispatch("keydown", { key: "Enter" });
assert.equal(submits, 2, "Enter without an open suggestion keeps regular search working");

console.log("PASS debounced, accessible keyboard autocomplete and regular Enter search");
