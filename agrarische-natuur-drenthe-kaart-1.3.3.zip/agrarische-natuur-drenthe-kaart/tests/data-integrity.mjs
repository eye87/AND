import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import url from "node:url";
import vm from "node:vm";

const root = path.resolve(path.dirname(url.fileURLToPath(import.meta.url)), "..");
const browserWindow = {};
vm.runInNewContext(
  fs.readFileSync(path.join(root, "assets", "geometry.js"), "utf8"),
  { window: browserWindow, Object, Infinity, Number, Math }
);
const geometry = browserWindow.ANDGeometry;

function readGeoJson(name) {
  return JSON.parse(fs.readFileSync(path.join(root, "data", name), "utf8"));
}

function coordinatesOf(geometry) {
  const polygons = geometry.type === "Polygon" ? [geometry.coordinates] : geometry.coordinates;
  return polygons.flatMap(polygon => polygon.flatMap(ring => ring));
}

function validateDataset(name, allowedCodes, property) {
  const data = readGeoJson(name);
  assert.equal(data.type, "FeatureCollection");
  assert.ok(data.features.length > 0, `${name} is leeg`);

  for (const feature of data.features) {
    assert.ok(["Polygon", "MultiPolygon"].includes(feature.geometry.type));
    const code = String(feature.properties?.[property] || "");
    assert.ok(allowedCodes.some(allowed => code.includes(allowed)), `Onbekende code ${code}`);
    for (const [lon, lat] of coordinatesOf(feature.geometry)) {
      assert.ok(Number.isFinite(lon) && Number.isFinite(lat));
      assert.ok(lon >= 5.5 && lon <= 7.6 && lat >= 52.2 && lat <= 53.5);
    }
  }
  return data.features.length;
}

const agrarischCount = validateDataset(
  "agrarisch_2026.geojson",
  ["A11", "A12", "A15"],
  "agrarischNatuurType"
);
const waterCount = validateDataset(
  "water_klimaat_2026.geojson",
  ["W01", "K01"],
  "waterClimateType"
);

const square = {
  type: "Polygon",
  coordinates: [[[6, 52.5], [7, 52.5], [7, 53.2], [6, 53.2], [6, 52.5]]]
};
assert.equal(geometry.pointInPolygonGeometry([6.5, 53], square), true);
assert.equal(geometry.pointInPolygonGeometry([5.8, 53], square), false);
assert.equal(geometry.boundsIntersect(geometry.bounds(square), geometry.bounds(square)), true);

console.log(`Data- en geometrietests geslaagd: ${agrarischCount} agrarische en ${waterCount} water-/klimaatgeometrieën.`);
