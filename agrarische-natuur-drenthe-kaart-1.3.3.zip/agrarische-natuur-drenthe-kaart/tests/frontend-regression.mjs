import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";

// Execute production functions in isolation with controlled map/network failures.
const source=["perceelscheck", "datasets", "map-view", "pdok", "results-view"]
  .map(name=>fs.readFileSync(new URL(`../assets/${name}.js`,import.meta.url),"utf8")).join("\n");
function functionSource(name) {
  const start=source.search(new RegExp("    (?:async )?function "+name+"\\("));
  assert.ok(start>=0,name);
  const end=source.indexOf("\n    }",start);
  return source.slice(start,end+6);
}
function context(names,values) {
  const ctx=vm.createContext(values);
  vm.runInContext(names.map(functionSource).join("\n"),ctx);
  return ctx;
}
const activeLayers=new Set(["water"]);
const layers=new Map(), sources=new Map();
const map={
  getSource:id=>sources.get(id),
  addSource:(id,s)=>sources.set(id,s),
  getLayer:id=>layers.get(id),
  addLayer:l=>layers.set(l.id,l),
  setLayoutProperty:(id,k,v)=>{layers.get(id).layout[k]=v;}
};
const feature=code=>({type:"Feature",properties:{waterClimateType:code},geometry:{type:"Polygon",coordinates:[]}});
const w=feature("W01"),k=feature("K01");
const fc=()=>({type:"FeatureCollection",features:[]});
const waterSources={},anlbByCategory={water:fc()};
const ctx=context(["setCategoryVisibility","loadInlineWaterClimate","addAnlbLayers"],{
  map,activeLayers,waterSources,anlbByCategory,categories:{water:{color:"#3973b7"}},
  dataUrls:{climate:"climate.js"},window:{ANLB_WATER_DATA:{features:[w]},ANLB_KLIMAAT_DATA:{features:[k]}}
});
ctx.setCategoryVisibility("water",false); // User unticks while downloads are pending.
ctx.loadInlineWaterClimate();ctx.addAnlbLayers(Object.keys(waterSources));
assert.equal(layers.size,4);
for(const l of layers.values())assert.equal(l.layout.visibility,"none");
assert.notEqual(sources.get("anlb-water").data,sources.get("anlb-climate").data);
assert.equal(anlbByCategory.water.features.length,2);
ctx.setCategoryVisibility("water",true);
for(const l of layers.values())assert.equal(l.layout.visibility,"visible");
console.log("PASS separate sources, combined results, retained selection during loading");

const failing=context(["safeBooleanIntersects"],{turf:{booleanIntersects(){throw Error("bad geometry");}},console:{warn(){}}});
assert.throws(()=>failing.safeBooleanIntersects({},{}),/niet betrouwbaar/);
console.log("PASS failed overlap calculation never becomes a negative result");

// Full search/click sequences are covered in selection-regression.mjs.

const legacy=context(["loadInlineWaterClimate"],{
  dataUrls:{},window:{ANLB_WATER_KLIMAAT_2026:{features:[w,k]}},
  waterSources:{},anlbByCategory:{water:fc()}
});
assert.equal(legacy.loadInlineWaterClimate().total,2);
console.log("PASS combined legacy dataset");
