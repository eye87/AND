import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";

function element() {
  const classes = new Set();
  const listeners = new Map();
  return {
    placeholder: "Bekijk je kansen per adres",
    attributes: new Map(),
    focused: false,
    classList: { toggle: (name, active) => active ? classes.add(name) : classes.delete(name), contains: name => classes.has(name) },
    addEventListener(type, handler) { listeners.set(type, handler); },
    dispatch(type, event = {}) { listeners.get(type)?.({ target: this, ...event }); },
    setAttribute(name, value) { this.attributes.set(name, String(value)); },
    contains(target) { return target === this; },
    focus() { this.focused = true; }
  };
}

const documentListeners = new Map();
const mediaListeners = new Map();
const mediaQuery = {
  matches: true,
  addEventListener(type, handler) { mediaListeners.set(type, handler); }
};
const document = { addEventListener(type, handler) { documentListeners.set(type, handler); } };
let requestedMediaQuery = "";
const window = { matchMedia: query => {
  requestedMediaQuery = query;
  return mediaQuery;
} };
const context = vm.createContext({ window, document });
vm.runInContext(fs.readFileSync(new URL("../assets/mobile-controls.js", import.meta.url), "utf8"), context);
const css = fs.readFileSync(new URL("../assets/perceelscheck.css", import.meta.url), "utf8");

const appRoot = element();
const addressInput = element();
const layersToggle = element();
const layerList = element();
context.window.ANDPerceelscheck.createMobileControls({ appRoot, addressInput, layersToggle, layerList });

assert.equal(requestedMediaQuery, "(max-width: 1024px)");
assert.match(css, /Mobile Safari zooms the page[\s\S]*?font-size:\s*16px/);
assert.match(css, /@media \(min-width: 1025px\) and \(pointer: coarse\)/);
assert.match(css, /@media \(max-width: 699px\)[\s\S]*?padding-bottom:\s*calc\(75% \+ 100px\)/);
assert.equal(addressInput.placeholder, "Bekijk je kansen per adres");
layersToggle.dispatch("click");
assert.equal(layersToggle.attributes.get("aria-expanded"), "true");
assert.equal(layerList.classList.contains("mobile-open"), true);

let prevented = false;
documentListeners.get("keydown")({ key: "Escape", preventDefault() { prevented = true; } });
assert.equal(prevented, true);
assert.equal(layersToggle.attributes.get("aria-expanded"), "false");
assert.equal(layersToggle.focused, true);

mediaQuery.matches = false;
mediaListeners.get("change")();
assert.equal(addressInput.placeholder, "Bekijk je kansen per adres");
assert.equal(layerList.classList.contains("mobile-open"), false);

console.log("PASS mobile placeholder and accessible layer popover state");
