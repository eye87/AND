import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";

const source = fs.readFileSync(new URL("../assets/pdok.js", import.meta.url), "utf8");
let fetchImpl;
const context = vm.createContext({
  window: {}, URL, AbortController, setTimeout, clearTimeout,
  fetch: (...args) => fetchImpl(...args)
});
vm.runInContext(source, context);
const geometry = { pointInPolygonGeometry: (point, polygon) => polygon.contains };
const api = context.window.ANDPerceelscheck.createPdok({ geometry, timeoutMs: 20 });
const point = { lng: 6.6, lat: 53 };
const neighbour = { geometry: { contains: false } };
const containing = { geometry: { contains: true } };
let calls = 0;

let suggestionUrl;
fetchImpl = async url => {
  suggestionUrl = new URL(url);
  return { ok: true, json: async () => ({ response: { docs: [
    { id: "weg-1", type: "weg", weergavenaam: "Brink, Assen" },
    { id: "adres-1", type: "adres", weergavenaam: "Brink 1, 9401 HS Assen" },
    { id: "adres-2", type: "adres", weergavenaam: "Brink 1, 9401 HS Assen" },
    { id: "gebied-1", type: "gemeente", weergavenaam: "Assen" }
  ] } }) };
};
assert.deepEqual(
  JSON.parse(JSON.stringify(await api.suggestAddresses("Brink"))),
  [
    { id: "weg-1", type: "weg", label: "Brink, Assen" },
    { id: "adres-1", type: "adres", label: "Brink 1, 9401 HS Assen" }
  ]
);
assert.equal(suggestionUrl.pathname.endsWith("/suggest"), true);
assert.equal(suggestionUrl.searchParams.get("fq"), "provincienaam:Drenthe");
assert.equal(suggestionUrl.searchParams.get("rows"), "8");
console.log("PASS autocomplete suggestions are filtered, limited and deduplicated");

fetchImpl = async () => { calls++; return { ok: true, json: async () => ({ features: [neighbour] }) }; };
assert.equal(await api.findParcelAtPoint(point), null);
assert.equal(calls, 3);
fetchImpl = async () => ({ ok: true, json: async () => ({ features: [neighbour, containing] }) });
assert.equal(await api.findParcelAtPoint(point), containing);
console.log("PASS neighbouring parcel is never used; containing parcel is selected");

let signal;
fetchImpl = (url, options) => { signal = options.signal; return new Promise(() => {}); };
await assert.rejects(api.findAddress("Assen"), error => error.code === "PDOK_TIMEOUT");
assert.equal(signal.aborted, true);
fetchImpl = async () => ({ ok: true, json: () => new Promise(() => {}) });
await assert.rejects(api.findParcelAtPoint(point), error => error.code === "PDOK_TIMEOUT");
fetchImpl = async () => ({ ok: false });
await assert.rejects(api.findParcelAtPoint(point), /geen geldig antwoord/);
fetchImpl = async () => ({ ok: true, json: async () => ({ response: { docs: [] } }) });
assert.equal(await api.findAddress("Assen"), null);
console.log("PASS request and body timeouts, HTTP error, and successful retry");
