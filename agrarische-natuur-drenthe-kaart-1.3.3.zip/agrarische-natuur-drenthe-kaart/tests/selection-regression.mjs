import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";

// Exercise complete production modules together. Only browser/MapLibre/network
// boundaries are doubled; selection state and padding are the production code.
const moduleNames = ["geometry", "map-view", "results-view", "selection-controller"];
const code = moduleNames.map(name => fs.readFileSync(new URL(`../assets/${name}.js`, import.meta.url), "utf8")).join("\n");
function element() {
  const classes = new Set();
  return {
    textContent: "", innerHTML: "", value: "Brink 1 Assen", open: false, disabled: false,
    classList: {
      add: (...names) => names.forEach(n => classes.add(n)),
      remove: (...names) => names.forEach(n => classes.delete(n)),
      contains: n => classes.has(n),
      toggle(n, active) { active ? classes.add(n) : classes.delete(n); }
    },
    setAttribute() {}, appendChild() {}, append() {}
  };
}
const rect = (left, top, width, height) => ({ left, top, width, height, right: left + width, bottom: top + height });
const parcel = {
  type: "Feature", properties: { perceelnummer: 1 },
  geometry: { type: "Polygon", coordinates: [[[6.6,53],[6.61,53],[6.61,53.01],[6.6,53.01],[6.6,53]]] }
};
const point = { lng: 6.605, lat: 53.005 };
const doc = { weergavenaam: "Testadres", woonplaatsnaam: "Assen", gemeentenaam: "Assen" };
function fixture(width = 1297, height = 865, panelAtBottom = false) {
  const ui = Object.fromEntries([
    "addressInput", "searchBtn", "searchStatus", "locationName", "locationMeta", "parcelCard", "parcelSummary",
    "parcelMunicipality", "parcelSection", "parcelNumber", "parcelArea", "resultBox", "resultTitle", "resultList"
  ].map(name => [name, element()]));
  const markers = new Set(), fits = [], moves = [], sources = new Map();
  const canvas = rect(20, 60, width, height);
  let panelOverride;
  const panelRect = () => panelOverride || (panelAtBottom
    ? rect(canvas.left, canvas.bottom, width,
      ui.resultBox.classList.contains("visible") ? height * 0.66 : 380)
    : rect(canvas.right - 428, canvas.top + 18, 410, Math.min(650, height - 36)));
  const map = {
    getContainer: () => ({ getBoundingClientRect: () => canvas }),
    getSource: id => sources.get(id),
    addSource(id, value) { sources.set(id, { data: value.data, setData(data) { this.data = data; } }); },
    addLayer() {}, stop() {},
    getZoom: () => 16,
    easeTo: options => moves.push(options),
    fitBounds(bounds, options) {
      const p = options.padding;
      assert.ok(p.left + p.right < width, "horizontal padding must leave visible map");
      assert.ok(p.top + p.bottom < height, "vertical padding must leave visible map");
      assert.ok(Object.values(p).every(n => Number.isFinite(n) && n >= 0));
      fits.push({ bounds, ...options });
    }
  };
  const ctx = vm.createContext({
    window: {}, console: { error() {} }, document: { createElement: element },
    maplibregl: { Marker: class {
      setLngLat(p) { this.point = p; return this; }
      addTo() { markers.add(this); return this; }
      remove() { markers.delete(this); }
    } }
  });
  vm.runInContext(code, ctx);
  const api = ctx.window.ANDPerceelscheck;
  const view = api.createMapView({ map, geometry: ctx.window.ANDGeometry,
    appRoot: { querySelector: () => ({ getBoundingClientRect: panelRect }) }, ...ui });
  const pdok = { findAddress: async () => ({ doc, point }), findParcelAtPoint: async () => parcel, reverseGeocode: async () => doc };
  const dependencies = { isReady: () => true, map, view, pdok, ...ui,
    checkParcelAgainstAnlb: () => [{ overlaps: true, label: "Dooradering", url: "https://example.com" }],
    renderResults: api.createResultsView(ui).renderResults };
  const controller = api.createSelectionController(dependencies);
  return { ...ui, ...controller, pdok, view, markers, sources, fits, moves, canvas,
    setPanel: value => { panelOverride = value; } };
}

for (const [width, height, bottom] of [[280,920,true],[330,920,true],[390,920,true],[640,780,true],[700,780,false],[1297,865,false]]) {
  const f = fixture(width, height, bottom);
  f.view.fitInitialProvinceView();
  await f.searchAndCheckParcel();
  const fit = f.fits.at(-1);
  assert.equal(fit.maxZoom, 12.5);
  if (bottom) {
    const gap = Math.min(32, width / 10, height / 10);
    assert.equal(fit.padding.bottom, gap, "detached result panel must not reduce the map viewport");
    assert.equal(fit.padding.right, gap);
  } else assert.ok(fit.padding.right > 410);
  // Protect embedded maps whose theme lets the panel cover almost the entire map.
  f.setPanel(rect(f.canvas.left, f.canvas.top, width, height));
  f.view.fitInitialProvinceView();
}
console.log("PASS responsive fit at 280–1297px, final panel height, and oversized panel");

for (const width of [280, 330, 390, 580]) {
  const height = width * 0.75;
  const mobile = fixture(width, height, true);
  // The result panel begins below the 4:3 map and never covers it.
  mobile.setPanel(rect(mobile.canvas.left, mobile.canvas.bottom, width, 600));
  mobile.view.fitInitialProvinceView();
  const initialPadding = mobile.fits.at(-1).padding;
  assert.equal(initialPadding.bottom, Math.min(32, width / 10, height / 10));
  assert.equal(initialPadding.left, initialPadding.right);
  mobile.setPanel(rect(mobile.canvas.left, mobile.canvas.bottom, width, 1000));
  await mobile.searchAndCheckParcel();
  assert.deepEqual(mobile.fits.at(-1).padding, initialPadding);
}
console.log("PASS detached mobile panel never reduces the map viewport");

const f = fixture();
const selected = () => f.sources.get("selected-parcel").data.features.length;
await f.searchAndCheckParcel();
assert.equal(selected(), 1); assert.equal(f.markers.size, 1);
f.parcelCard.open = true;
f.pdok.findAddress = async () => null;
await f.searchAndCheckParcel();
assert.equal(selected(), 0); assert.equal(f.markers.size, 0);
assert.equal(f.parcelCard.open, false);
assert.equal(f.resultBox.classList.contains("visible"), false);
assert.equal(f.parcelCard.classList.contains("visible"), false);
assert.match(f.searchStatus.textContent, /Geen bruikbaar adres/);

f.pdok.findAddress = async () => ({ doc, point });
await f.searchAndCheckParcel();
f.pdok.findParcelAtPoint = async () => null;
await f.selectPointOnMap(point);
assert.equal(selected(), 0);
assert.equal(f.resultBox.classList.contains("visible"), false);
assert.match(f.parcelSummary.textContent, /Geen kadastraal perceel/);
assert.equal(f.markers.size, 1, "only the current selected position remains");

const timeout = () => { const e = new Error("PDOK reageert niet op tijd. Probeer het opnieuw."); e.code = "PDOK_TIMEOUT"; throw e; };
for (const action of [() => f.searchAndCheckParcel(), () => f.selectPointOnMap(point)]) {
  f.pdok.findParcelAtPoint = async () => parcel;
  await f.searchAndCheckParcel();
  f.pdok.findParcelAtPoint = async () => timeout();
  await action();
  assert.equal(selected(), 0); assert.equal(f.markers.size, 0);
  assert.equal(f.searchBtn.disabled, false);
  assert.equal(f.resultBox.classList.contains("visible"), false);
  assert.equal(f.parcelCard.classList.contains("visible"), false);
  assert.match(f.searchStatus.textContent, /niet op tijd/);
}
f.pdok.findParcelAtPoint = async () => parcel;
await f.searchAndCheckParcel();
assert.equal(selected(), 1); assert.equal(f.searchStatus.textContent, "");
const previousFitCount = f.fits.length;
await f.selectPointOnMap(point);
assert.equal(f.fits.length, previousFitCount, "map clicks preserve the user's zoom");
assert.equal(f.moves.at(-1).zoom, 16);
console.log("PASS success → no result → no parcel → timeout → retry across both selection routes");

let release, requests = 0;
f.pdok.findAddress = () => { requests++; return new Promise(resolve => { release = resolve; }); };
const first = f.searchAndCheckParcel();
assert.equal(selected(), 0, "clear previous parcel immediately, not after the network response");
assert.equal(f.markers.size, 0);
await f.searchAndCheckParcel();
await f.selectPointOnMap(point);
assert.equal(requests, 1);
assert.equal(f.searchBtn.disabled, true);
release(null); await first;
assert.equal(f.searchBtn.disabled, false);
console.log("PASS shared busy guard blocks double Enter and map click during search");

const second = fixture();
await second.searchAndCheckParcel();
f.pdok.findAddress = async () => timeout();
await f.searchAndCheckParcel();
assert.equal(second.sources.get("selected-parcel").data.features.length, 1);
assert.equal(second.markers.size, 1);
console.log("PASS resetting one map does not affect another map instance");
